package mazeGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import maze.Cell;
import maze.Maze;

public class KruskalGenerator implements MazeGenerator {
	
	private ArrayList<CellEdge> edges = new ArrayList<>();
	
	
	private ArrayList<Integer> directions = new ArrayList<>();
	

	public KruskalGenerator() {
		directions.addAll(Arrays.asList(new Integer[] {Maze.NORTH, Maze.EAST, Maze.SOUTH, Maze.WEST}));
		
	}
	
	@Override
	public void generateMaze(Maze maze) {
		createEdges(maze);
		
		
	} // end of generateMaze()
	
	private void createEdges(Maze maze){
		
	
		for (int i =0; i < maze.sizeR; i++) {
			
			for(int j = 0; j < maze.sizeC; j++) {
				
				if(i >= 0 ) {
					edges.add(new CellEdge(i, j, Maze.WEST));
				}

				if(j >= 0) {
					edges.add(new CellEdge(i ,j, Maze.NORTH));
				}
			}
		}
		
		Collections.shuffle(edges);
		
		Sets set = new Sets(maze.sizeC * maze.sizeR);
		
		for(int i = 0; i < edges.size(); i++) {
			
			CellEdge edge = edges.get(i);
			
			Cell currCell = maze.map[edge.getPosX()][edge.getPosY()];
			
			if(currCell.tunnelTo != null) {
				set.union(currCell.r * maze.sizeC + currCell.c, currCell.tunnelTo.r * maze.sizeC + currCell.tunnelTo.c);
				continue;
			}
			
			Cell nextCell = maze.map[edge.getPosX()][edge.getPosY()].neigh[edge.getDirection()];
			
			if(nextCell != null) {
				if(set.union(currCell.r * maze.sizeC + currCell.c, nextCell.r * maze.sizeC + nextCell.c)) {
					maze.map[currCell.r][currCell.c].wall[edge.getDirection()].present = false;
					maze.map[nextCell.r][nextCell.c].wall[Maze.oppoDir[edge.getDirection()]].present = false;
				}
			}
		}
	}

}
	
	
	
	


