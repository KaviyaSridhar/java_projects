package mazeGenerator;

public class Sets {

	private int parent[];
	
	private int rank[];
	
	private int size;
	
	public Sets(int size) {
		this.size = size;
		parent = new int[size];
		rank = new int[size];
		for(int i = 0; i < size ; i++) {
			this.makeSet(i);
		}
	}
	
	private void makeSet(int i) {
		parent[i] = i;
		rank[i] = 0;
	}
	
	public int getSize() {
		return size;
	}
	
	public int find(int i) {
		
		if(i != parent[i]) {
			parent[i] =find(parent[i]);
		}
		return parent[i];
	}
	
	public boolean union(int i,int j) {
		
		int rowRoot = find(i);
		
		int colRoot = find(j);
		
		if(rowRoot == colRoot) {
			return false;
		}
		
		if(rank[rowRoot]< rank[rowRoot]) {
			parent[rowRoot] = colRoot;
		}else {
			parent[colRoot] = rowRoot;
            if (rank[rowRoot] == rank[colRoot])
                rank[rowRoot]++;
        }
        	size--;
        	return true;
		}
		
}
	
	

