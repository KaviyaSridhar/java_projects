package mazeGenerator;

import java.util.ArrayList;

import maze.Cell;

public class CellEdge {
	
	private int posX;
	
	private int posY;
	
	private int direction;
	
	public CellEdge(int x, int y, int dir) {
		posX = x;
		posY = y;
		direction = dir;
	}
	
	public int getPosX() {
		return this.posX;
	}
	
	public int getPosY() {
		return this.posY;
	}
	
	
	public int getDirection() {
		return this.direction;
	}
	
	
}
