package mazeGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

import maze.Cell;
import maze.Maze;

public class HuntAndKillGenerator implements MazeGenerator {
	
	private Cell currentCell;
	
	private Cell neighCell;
	
	private boolean[][] isVisited;
	
	private ArrayList<Integer> directions = new ArrayList<>();
	
	//private int[] directions = new int[] {Maze.NORTH, Maze.EAST, Maze.SOUTH, Maze.WEST};
	
	public HuntAndKillGenerator() {
		directions.addAll(Arrays.asList(new Integer[] {Maze.NORTH, Maze.EAST, Maze.SOUTH, Maze.WEST}));
	}
	
	@Override
	public void generateMaze(Maze maze) {
		
		boolean exit = false;
		isVisited = new boolean[maze.sizeR][maze.sizeC];
		currentCell = getRandomCell(maze);
		isVisited[currentCell.r][currentCell.c] = true; // make the cell visited
		while(!exit) {
			Cell cell = goWalk(maze);
			if(cell == null) {
				cell = goHunt(maze);
				if(cell == null) {
					exit = true;
				}
			}
		}
		
	} // end of generateMaze()
	
	private Cell goWalk(Maze maze) {
		
		Collections.shuffle(directions);
		
		for(int dir : directions) {
			
			if(currentCell.tunnelTo != null && (!isVisited[currentCell.tunnelTo.r][currentCell.tunnelTo.c])) {
				neighCell = currentCell.tunnelTo;
				isVisited[neighCell.r][neighCell.c] = true;
				currentCell = neighCell;
			}else if((currentCell.neigh[dir] != null) && (!isVisited[currentCell.neigh[dir].r][currentCell.neigh[dir].c])) {
				neighCell  = currentCell.neigh[dir];
				maze.map[currentCell.r][currentCell.c].wall[dir].present = false;
				maze.map[neighCell.r][neighCell.c].wall[Maze.oppoDir[dir]].present = false;
				isVisited[neighCell.r][neighCell.c] = true;
				currentCell = neighCell;
				System.out.println("Next Cell ("+currentCell.r+","+currentCell.c+")" );
				return neighCell;
			}	
		}
		
		return null;
	}
	
	public Cell goHunt(Maze maze) {
		//System.out.println("Entered Hunt mode");
		
		for(int i = 0; i < maze.sizeR ; i++) {
			
			for(int j = 0; j < maze.sizeC; j++) {	
				
				Cell cell = maze.map[i][j];
				
				//System.out.println("Current Cell ( " + currentCell.r +","+ currentCell.c +")");
				
				if(cell!=null && cell.c == currentCell.c && cell.r == currentCell.r) {
					continue;
				}
				
				if(cell!= null && isVisited[cell.r][cell.c]) {
					continue;
				}
				
				for(int k = 0; k < directions.size(); k++) {
					
					Cell neigh = cell.neigh[directions.get(k)];
					
					if(neigh != null && isVisited[neigh.r][neigh.c]) {
						currentCell = cell;
						maze.map[currentCell.r][currentCell.c].wall[directions.get(k)].present = false;
						maze.map[neigh.r][neigh.c].wall[Maze.oppoDir[directions.get(k)]].present = false;
						isVisited[currentCell.r][currentCell.c] = true;
						System.out.println("Finally hunted  Cell ( " + currentCell.r +","+ currentCell.c +")");
						return cell;
					}
				}
			}
			
		}
		
		return null;
	}
	
	private Cell getRandomCell(Maze maze) {
		
		int rowx;
		int rowy;
		
		Random random = new Random();
		
		rowx = random.nextInt(maze.sizeR);
		
		rowy = random.nextInt(maze.sizeC);
		
		return maze.map[rowx][rowy];
	}
	 

} // end of class HuntAndKillGenerator
