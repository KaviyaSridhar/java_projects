package mazeSolver;                                                                                                                                                         
                                                                                                                                                                            
import java.util.ArrayList;                                                                                                                                                 
import java.util.Arrays;                                                                                                                                                    
import java.util.LinkedList;                                                                                                                                                
import java.util.Queue;                                                                                                                                                     
                                                                                                                                                                            
import maze.Cell;                                                                                                                                                           
import maze.Maze;                                                                                                                                                           
                                                                                                                                                                            
/**                                                                                                                                                                         
 * Implements the recursive backtracking maze solving algorithm.                                                                                                            
 */                                                                                                                                                                         
                                                                                                                                                                            
                                                                                                                                                                            
public class RecursiveBacktrackerSolver implements MazeSolver {                                                                                                             
	                                                                                                                                                                        
	private Cell currentCell, exitCell;                                                                                                                                     
	int[][] steps;                                                                                                                                                          
	private ArrayList<Integer> celldirectios = new ArrayList<>();                                                                                                                                                                                                                                                              
	boolean[][] visited;                                                                                                                                                    
	boolean[][] solutionPath;
	private boolean solved = false;
	private int totalCellCount = 0;
	public RecursiveBacktrackerSolver() {                                                                                                                                   
		celldirectios.addAll(Arrays.asList(new Integer[] {Maze.NORTH, Maze.EAST, Maze.SOUTH, Maze.WEST}));                                                                     
	}                                                                                                                                                                       
	                                                                                                                                                                       
	@Override                                                                                                                                                               
	public void solveMaze(Maze maze) {                                                                                                                                      
		visited = new boolean[maze.sizeR][maze.sizeC];                                                                                                                      
		solutionPath = new boolean[maze.sizeR][maze.sizeC];                                                                                                                  
		exitCell = maze.exit;                                                                                                                                               
		solved = solveDSFMaze(maze, maze.entrance);                                                                                                                                      
		for(int i = 0; i < maze.sizeR ; i++) {                                                                                                                              
			for(int j = 0 ; j < maze.sizeC; j++) {                                                                                                                          
				if(solutionPath[i][j] == true) {                                                                                                                             
					maze.drawFtPrt(new Cell(i,j));                                                                                                                          
				}                                                                                                                                                           
			}                                                                                                                                                               
		}                                                                                                                                                                   
		                                                                                                                                                                    
	} // end of solveMaze()                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                                               
	@Override                                                                                                                                                               
	public boolean isSolved() {                                                                                                                                             
		return solved;                                                                                                                                               
	} // end if isSolved()                                                                                                                                                  
                                                                                                                                                                            
	public boolean solveDSFMaze(Maze maze, Cell thisCell) {                                                                                                                  
		                                                                                                                                                                    
		                                                                                                                                                                                                                                                                                                                                   
		                                                                                                                                                                    
		if(thisCell.r == exitCell.r && thisCell.c == exitCell.c) {  
			totalCellCount++;
			this.visited[thisCell.r][thisCell.c] = true;                                                                                                              
			this.solutionPath[thisCell.r][thisCell.c] = true;                                                                                                          
			return true;                                                                                                                                                    
		}                                                                                                                                                                   
		Cell prevCell = null;                                                                                                                  
		if(thisCell.r >= 0 && thisCell.c >= 0 && thisCell.r < maze.sizeR && thisCell.c < maze.sizeC && !visited[thisCell.r][thisCell.c]) {                
			                                                                                                                                                                
			if(thisCell.tunnelTo != null) { 
				totalCellCount++;
				solutionPath[thisCell.r][thisCell.c] = true;                                                                                                           
				this.visited[thisCell.r][thisCell.c] = true;  
				prevCell = thisCell;
				thisCell = thisCell.tunnelTo;                                                                                                                                                                                                                                                                                    
			}                                                                                                                                                               
			                                                                                                                                                                
			this.visited[thisCell.r][thisCell.c] = true;                                                                                                              
			                                                                                                                                                                
			if(!thisCell.wall[celldirectios.get(0)].present && solveDSFMaze(maze, thisCell.neigh[celldirectios.get(0)])) {                                                      
				solutionPath[thisCell.r][thisCell.c] = true; 
				totalCellCount++;
				return true;                                                                                                                                                
			}                                                                                                                                                               
			if(!thisCell.wall[celldirectios.get(1)].present && solveDSFMaze(maze, thisCell.neigh[celldirectios.get(1)])) {                                                      
				solutionPath[thisCell.r][thisCell.c] = true;
				totalCellCount++;
				return true;                                                                                                                                                
			}                                                                                                                                                               
			if(!thisCell.wall[celldirectios.get(2)].present && solveDSFMaze(maze, thisCell.neigh[celldirectios.get(2)])) {                                                      
				solutionPath[thisCell.r][thisCell.c] = true; 
				totalCellCount++;
				return true;                                                                                                                                                
			}                                                                                                                                                               
			if(!thisCell.wall[celldirectios.get(3)].present && solveDSFMaze(maze, thisCell.neigh[celldirectios.get(3)])) {                                                      
				solutionPath[thisCell.r][thisCell.c] = true; 
				totalCellCount++;
				return true;                                                                                                     	                                        
		    }                                                                                                                                                               
		}                                                                                                                                                                   
		
		if(prevCell != null) {
			totalCellCount--;
			solutionPath[prevCell.r][prevCell.c] = false;  
		}
		
		return false;                                                                                                                                                       
		                                                                                                                                                                    
	}                                                                                                                                                                       
	                                                                                                                                                                        
	@Override                                                                                                                                                               
	public int cellsExplored() {                                                                                                                                            
		                                                                                                                           
		return totalCellCount;                                                                                                                                                          
	}                                                                                                                                         
}                                                                                                                                
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
	                                                                                                                                                                        
	                                                                                                                                                                        
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            
                                                                                                                                                                            