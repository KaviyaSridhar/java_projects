public class PlayStoreMain {

	public static void main(String[] args) {

		PlayStore store = new PlayStore();
		
		// Book and Magazines are initialized
		String[] authors1 = { "L. Tolstoy" };
		Book b1 = new Book("R1", "War and Peace", 12, "The Russian Messenger", "Novel", 1225, authors1);
		
		String[] authors2 = { "F. Scott Fitzgerald" };
		Book b2 = new Book("R2", "The great gatsby", 10, "Charles Scribner's Sons", "Novel", 180, authors2);

		String[] authors3 = { "Thomas H. Cormen", "Charles E. Leiserson", "Ronald L. Rivest", "Clifford Stein" };
		Book b3 = new Book("R3", "Introduction to algorithms", 100, "MIT Press", "Computer Science", 1312, authors3);

		Magazine m1 = new Magazine("m1", "Forbes", 8, "Forbes Media", "Business", 50, "World�s richest under 30");

		// Books and Magazine are added to Reading class
		store.add(b1.getID(),b1);
		store.add(b2.getID(),b2);
		store.add(m1.getID(),m1);
		store.add(b3.getID(),b3);
		
		// Mobile operating system types with version number are initialized
		OS androidV4 = new OS("Android", 4);
		OS iOSV10 = new OS("iOS", 10);
		OS androidV3 = new OS("Android", 3);

		//Games are initialized
		Game g1 = new Game("g1", "Pokemon", 5, false, androidV4);
		Game g2 = new Game("g2", "Pokemon", 5, false, iOSV10);
		Game g3 = new Game("g3", "MineCraft", 2, true, androidV3);

		// Games readings are added to the playstore
		store.add(g1.getID(),g1);
		store.add(g2.getID(),g2);
		store.add(g3.getID(),g3);

		//User is initialized with ID, name, phone number, balance and OS object
		User u1 = new User("u1", "John Doe", "0412000", 2000, androidV4);
		User u2 = new User("u2", "Jane Doe", "0412001", 120, androidV4);
		User u3 = new User("u3", "Dave Roe", "0412002", 100, iOSV10);
		User u4 = new User("u4", "Diane Roe", "0412003", 50, androidV3);

		//Users are added into PlayStore
		store.add(u1);
		store.add(u2);
		store.add(u3);
		store.add(u4);
	
		//buy content method called
		try {
			u1.buyContent(b1);		
			u1.buyContent(b3);		
			u1.buyContent(m1);			
			u4.buyContent(g1);
			
		} catch (CustomExp e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		u4.becomePremium();
		
		try {		
			u4.buyContent(m1);
			
		} catch (CustomExp e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();			
		}
			
		u2.becomePremium();
			
		try {		
			u2.buyContent(g2);
			
		} catch (CustomExp e) {
				
			// TODO Auto-generated catch block
			e.printStackTrace();
				
		}
		
		try {
			u2.buyContent(g1);
			
		} catch (CustomExp e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		// Shows list of all available contents and lists all the contents of that type
		store.showContent();
		
		store.showReadingOfGenre("Novel");

		//Show list of names of all the contents user has bought		
		u2.showContentBought();		
		
		// Review from User is added to content type of object
		Comment comment1 = new Comment(u1, "This is a fantastic game!");		
		g1.addReviews(comment1);		
		
		Comment reply1 = new Comment(u2, "I never liked this game!");
		comment1.addReply(reply1);
		
		Comment reply2 = new Comment(u1, "Why Not??");
		comment1.addReply(reply2);		

		Comment comment2 = new Comment(u3, "The game crashes frequently.");
		g1.addReviews(comment2);		 
		
		//Show reviews of a content object
		g1.showReviews();
	}
}