import java.util.ArrayList;

public class Comment {
	
	// Data members User type object
	private User userId;	
	
	//String comment is declared
	private String comment;
	
	// Collection of comment objects called reply is declared	
	private ArrayList<Comment> reply;
	
	// constructor for class Comment
	public Comment(User obj, String comnt) {
		
		this.comment = comnt;
		this.userId = obj;
		reply = new ArrayList<Comment>();
		
	}
	
	
	// getter functions
	public String getComment() {
		return comment;
	}
	
	
	public String getCommentUserId() {
		return userId.getID();
	}
	
	
	public String getCommentUserName() {
		return userId.getName();
	}
		
	
	// setter function for class Comment
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	// adding reply
	public void addReply(Comment comment){ 
		reply.add(comment);
	}
	
	
	// displaying reply
	public void showreply() {
		
		for(int i = 0; i < reply.size(); i++) {
			System.out.println("\t" + reply.get(i).getCommentUserName() + " (" + reply.get(i).getCommentUserId() + "): " + reply.get(i).getComment());
			
			if(i != reply.size()-1) {
				System.out.print("\t");
			}
		}
		
	}
	
}