public class Magazine extends Reading{

	// Data members for Reading class is declared	
	private String magTitle;
	
	// Constructor for Reading class
	public Magazine(String magId, String magName, int magPrice, String magPublisher, String magGenre, int magPageNum, String magTitle) {
		
		// Super class data members are initialized
		super(magId, magName, magPrice, magPublisher, magGenre, magPageNum);
		
		//Title for Magazine is initialized
		this.magTitle = magTitle;
	}
}
