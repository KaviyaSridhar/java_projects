import java.util.ArrayList;

public abstract class Content {
	
	// Declaring variables for Class Content
	private String ID;
	private String appName;
	private double price;
	private int noOfdownloads;
	
	//Collection of Comment objects named reviews is created
	private ArrayList<Comment> reviews;

	//Constructor for class Content	
	public Content(String content_app_id, String content_app_name, double content_app_price) {
		
		
		this.ID = content_app_id;
		this.setAppName(content_app_name);
		this.setPrice(content_app_price);
		
		// Number of downloads is initially set ot 0
		this.noOfdownloads = 0;
		
		// review is initialized inside constructor
		reviews = new ArrayList<Comment>();
		
	}
	
	
	//getter functions for the class Content		
	public String getID() {
		return ID;
	}
	
	
	public String getAppName() {
		return appName;
	}
	
	
	public double getPrice() {
		return price;
	}
	
		
	public double getAppPrice() {
		return getPrice();
	}
	
		
	public int getNoOfDownloads() {
		return noOfdownloads;
	}
	
	
	//setter function for the class Content	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	
	//the number of downloads of content is increased by 1 when the user buys
	public int setNoOfDownloads() {
		this.noOfdownloads = this.noOfdownloads + 1;
		return noOfdownloads;
	}
	
	
	//reviews which is a comment type of object is added
	public  void addReviews(Comment obj) {
		reviews.add(obj);
	}
	
	
	//reviews of the users are displayed
	public void showReviews() {
		
		System.out.println("\n");
		for (int i = 0; i < reviews.size(); i++) {
			
			System.out.println(reviews.get(i).getCommentUserName() + " (" + reviews.get(i).getCommentUserId() + ") : " + reviews.get(i).getComment());
			Comment c = reviews.get(i);
			
			c.showreply();
			System.out.println("\n");
		}
	}		
}