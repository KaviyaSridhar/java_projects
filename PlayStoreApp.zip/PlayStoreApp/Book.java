import java.util.*;

public class Book extends Reading {

	// Data members for reading class is declared	
	private String[] authors;	
	 
	// Constructor for the book class
	public Book(String book_id, String book_name, double book_price, String book_publisher, String book_genre, int book_page_num, String[] book_author) {
		
		// Using super for initializing the parent class data members
		super(book_id, book_name, book_price, book_publisher, book_genre, book_page_num);

		// author of book is initialized
		this.authors = book_author;
		
	}
	
	
	// Getter function for book class	
	public String getAuthors() {
		
		return Arrays.toString(authors);		
	}	
}