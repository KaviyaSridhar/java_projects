import java.util.ArrayList;

public class Game extends Content {
	
	// Data members for the Game class is declared	
	private boolean isMultiPlayer;
	
	// Instance class for OS type is declared
	private OS osType;		
	
	// Constructor for Game Class
	public Game(String app_id, String appName, double appPrice, boolean appMulti, OS type) {
		
		//Using super to set parent data members
		super(app_id, appName, appPrice);
		
		// Initializing the isMultiPlayer boolean variable 
		this.isMultiPlayer = appMulti;
		
		// Adding OS type to array list
		this.setOsType(type);		
	}
	
	
	//Getter and Setter function for OS class 
	public OS getOsType() {
		return osType;
	}

	
	public void setOsType(OS osType) {
		this.osType = osType;
	}
}
