import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PlayStore {
	
	// Collection of Content Objects
	private Map<String, Content> content;

	// Collection of User Objects
	private ArrayList<User> users;
	
	public PlayStore(){
		content = new HashMap<String, Content>();
		users = new ArrayList<User>();
	}
	
	
	// Add Contents
	public void add(String Id, Content obj) {
		content.put(Id, obj);
	}
	
	
	// Add method for adding new Users
	public void add(User obj) {

			users.add(obj);
			System.out.println(obj.getName() + " is added");
	}
	

	// Method to list all available contents and list the content for each type
	public void showContent() {
	System.out.println("\nList of all available contents");
		for (Object content : content.values()) {

			if (content.getClass() == Game.class) {

				System.out.println("Game name - " + ((Game) content).getAppName());

			}

			if (content.getClass() == Book.class) {

				System.out.println("Book name - " + ((Book) content).getAppName());

			}

			if (content.getClass() == Magazine.class) {

				System.out.println("Magazine name - " + ((Magazine) content).getAppName());

			}

		}
		
	}
		
	
	// it shows the list of all reading types with a given genre
	public void showReadingOfGenre(String genre) {
		
		System.out.println("\nContents of " + genre + " are:");
		
		for (Content c : content.values()) {
			
			if (c instanceof Reading ) {
				
				if (genre.equals(((Reading) c).getGenre())) {
					
					System.out.println("\t" + c.getAppName());
					
				}
			}
		}
		System.out.println();
	}

}

