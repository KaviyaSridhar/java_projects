public class OS {
	
	// Data members for type of operating system
	private String osType;
	
	//Data member for version of operating system
	private int verNum;
	
	// Constructor for initializing the data members
	public OS(String type, int vNum) {
		
		this.osType = type;
		this.verNum = vNum;
	}

	
	// getter function for OS type and version
	public String getAppOsType() {
		return osType;
	}
	
	
	public int getAppOsVersion() {
		return verNum;
	}
}