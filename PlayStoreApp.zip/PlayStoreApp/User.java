import java.util.ArrayList;

public class User {

	// Data members are created for the Class User
	private String id;
	private String name;
	private String phone;
	private double balance;

	// For the OS class instance variable is created
	private OS osType; 
	
	//Variable premium is declared to check if the user is a premium user or not
	private boolean premium;

	//Variable is initialized to store the discounted price after 20% discount	
	private double discountedAmount = (80.0f / 100.0f);
	
	// Array list to store list of Apps purchased by the user
	private ArrayList<String> purchaseapp = new ArrayList<String>() ;
	
	// Constructor for Class User
	public User(String uId, String uName, String uPhone, double uBalance, OS type) {
		
		this.setID(uId);
		this.setName(uName);
		this.phone = uPhone;
		this.balance = uBalance;
		this.osType = type;
		
		// The boolean variable is set to false denoting that initially the user is not premium
		this.premium = false;
		
	}

	
	public String getID() {
		return id;
	}


	public void setID(String id) {
		id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	
	// if user has no balance
	public User(String uId, String uName, String uPhone, OS type) {
		
		// setting data members
		this.setID(uId);
		this.setName(uName);
		this.phone = uPhone;
		
		// setting balance to 0
		this.balance = 0; 
		this.osType = type;

		// initially set user to no premium
		this.premium = false;
	}

	
	// Getter and setter methods for class Users
	public String getUserId() {
		return getID();
	}

	
	public String getUserName() {
		return getName();
	}

	
	public String getUserPhone() {
		return phone;
	}

	
	public double getUserBalance() {
		return balance;
	}

	
	// creating becomePremium method with exception class
	public void becomePremium() {
		
		// The user is checked whether the user is already premium
		if (!this.premium) {
			
			//If the cost of purchase is $100 the user becomes premium
			if (this.balance >= 100) {

				// The user is made premium next time 20% discount will be given on purchase
				this.premium = true;
				
				//$100 is reduced from balance for the purchase
				this.balance -= 100;
				
				//Show that the user has become premium
				System.out.println(this.getName() + " is now premium user!");
			}
			else {
				// Error will be shown if no balance
				System.out.println("Not enough Balance to become premium user" + " in " + this.getName() + " Account.");
			}
		}
		else {
			//Error will be shown if the user has already become premium
			System.out.println("User already a premium member");
		}

	}

	
	// buyContent method
	public void buyContent(Content obj) throws CustomExp {
		
		// Check if the content object is of type Game
		if (obj instanceof Game) {			

			// check the compatibility of the OS type and version number of the user
			if (this.osType.getAppOsType() == ((Game) obj).getOsType().getAppOsType()
					&& this.osType.getAppOsVersion() >= ((Game) obj).getOsType().getAppOsVersion()) {
				
				// If the compatibility us matching we check if the user is premium
				if (this.premium) {

					//Check if the user has the balance to pay the amount after getting 20% discount
					if (this.balance >= (double) (obj.getPrice() * discountedAmount)) {

						// the amount to be payed is deducted from the balance of the user
						this.balance -= (double) (obj.getPrice() * discountedAmount);
						
						//The number of downloads increased when the user buys it
						obj.setNoOfDownloads();
						
						(this.purchaseapp).add(obj.getAppName());
						
						System.out.println(this.getName() + " bought " + obj.getAppName());
					} 
					else {
						// Exception to print if the user has no enough balance
						throw new CustomExp(this.getName() + " doesn't have sufficient balance to purchase this");
					}
				}

				else {

					// If the user is not premium no discount applied and amount is deducted from balance
					if (this.balance >= obj.getPrice()) {
						
						// the amount to be payed is deducted from the balance of the 						user
						this.balance -= obj.getPrice();
						
						//The number of downloads increased when the user buys it
						obj.setNoOfDownloads();
						
						(this.purchaseapp).add(obj.getAppName());
							
						System.out.println(this.getName() + " bought " + obj.getAppName());
					}
					else {
						// Exception to print if the user has no enough balance
						throw new CustomExp(this.getName() + " doesn't have sufficient balance to purchase this");
					}

				}

				

			}
			else {
				// Exception if the OS of the user is not compatible
				throw new CustomExp(this.getName() + " cannot buy "+ obj.getAppName() + " for " + ((Game) obj).getOsType().getAppOsType() + " due to OS mismatch");				

			}

		}
		else {

			// if the content object is not of type Game
			// check whether the user is premium
			if (this.premium) {

				// Check if the user has the balance to pay the amount after getting 20% 					discount
				if (this.balance >= (double) (obj.getPrice() * discountedAmount)) {
					
					//the amount to be payed is deducted from the balance of the 						user
					this.balance -= (double) (obj.getPrice() * discountedAmount);
					
					//The number of downloads increased when the user buys it
					obj.setNoOfDownloads();
					
					(this.purchaseapp).add(obj.getAppName());
					
					System.out.println(this.getName() + " bought " + obj.getAppName());

				} 
				else {
					// use exception
					throw new CustomExp(this.getName() + " doesn't have sufficient balance to purchase this");
				}
			}

			else {

				// If the user is not premium
				if (this.balance >= obj.getPrice()) {
					
					//the amount to be payed is deducted from the balance of the 						user
					this.balance -= obj.getPrice();
					
					//The number of downloads increased when the user buys it
					obj.setNoOfDownloads();
					
					(this.purchaseapp).add(obj.getAppName());
					
					System.out.println(this.getName() + " bought " + obj.getAppName());

				}
				else {
					// use exception
					throw new CustomExp(this.getName() + " doesn't have sufficient balance to purchase this");
				}

			}
		}

	}

	
	// showContentsBought method
	public void showContentBought() {
		
		System.out.print("The contents bought by "+ this.getName() + " - ");		
		String value = "";
		
		for (String string : purchaseapp) {
             value += string + ",";
        }
		
		System.out.println(value.replaceAll(",$", ""));
	}
}