public abstract class Reading extends Content{
	
	// Variables declared for the class reading	
	private String publisher;
	private String genre;
	private int pageNum;
	
	// Constructor for the reading class
	public Reading(String rAppId, String rAppName, double rAppPrice, String rAppPublisher, String rAppGenre, int rAppPageNum) {
		
		// Using Super for parent class variables		
		super(rAppId, rAppName, rAppPrice);

		// Data members for Reading class is initialized
		this.publisher = rAppPublisher;
		this.genre = rAppGenre;
		this.pageNum = rAppPageNum;
	}	

	
	// getter and setter for reading class
	public String getAppPublisher() {
		return publisher;
	}
	
	
	public String getGenre() {
		return genre;
	}
	
	
	public int getAppPageNum() {
		return pageNum;
	}		
}
