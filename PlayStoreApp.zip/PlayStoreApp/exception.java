class CustomExp extends Exception {
	
      // Constructor
      public CustomExp(String message)
      {
         super(message);
      }
      
 }
