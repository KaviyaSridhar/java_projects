-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3308
-- Generation Time: May 24, 2019 at 11:39 AM
-- Server version: 5.6.34-log
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u462416137_pizza`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_reg`
--

CREATE TABLE `admin_reg` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_reg`
--

INSERT INTO `admin_reg` (`name`, `email`, `contact`, `address`, `username`, `password`) VALUES
('swati kedar', 'sonali@gmail.com', '1234567890', 'bgm', 'admin', 'admin123'),
('Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'kaviya', 'admin123'),
('sam', 'sam@gmail.com', '490203321', 'Unit 407/ 268 Flinders Street', 'sam', 'admin123'),
('mitali', 'mitali@gmail.com', '049020332', 'Unit 407/ 268 Flinders Street', 'mitali', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'swati kedar', 'swatikedar6@gmail.com', 'pizza', 'we wnt next time pepproni pizza');

-- --------------------------------------------------------

--
-- Table structure for table `cust_ship_details`
--

CREATE TABLE `cust_ship_details` (
  `id` int(11) NOT NULL,
  `order_no` varchar(50) NOT NULL,
  `cust_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `area` varchar(50) NOT NULL,
  `pin` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cust_ship_details`
--

INSERT INTO `cust_ship_details` (`id`, `order_no`, `cust_name`, `email`, `contact`, `address`, `area`, `pin`) VALUES
(61, 'ORDER_8797', 'Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'Gandhinagar', ''),
(60, 'ORDER_5821', 'Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'Area', ''),
(59, 'ORDER_6516', 'Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'Area', ''),
(58, 'ORDER_5482', 'Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'Area', ''),
(54, 'ORDER_3140', 'ash chavan', 'ashchavan12@gmail.com', '0452248043', 'australia', 'Area', '590006'),
(55, 'ORDER_5323', 'kaviya', 'kaviyasri7@gmail.com', '0490203321', 'adfDG', 'vadgav', ''),
(56, 'ORDER_8634', 'Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'Gandhinagar', ''),
(57, 'ORDER_8483', 'Kaviya Sridhar', 'kaviyasri7@gmail.com', '0490203321', 'Unit 407/ 268 Flinders Street', 'Area', '');

-- --------------------------------------------------------

--
-- Table structure for table `non_veg_pizza`
--

CREATE TABLE `non_veg_pizza` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL,
  `info` varchar(500) NOT NULL,
  `flavour` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `non_veg_pizza`
--

INSERT INTO `non_veg_pizza` (`id`, `name`, `image`, `price`, `info`, `flavour`) VALUES
('NonVeg_6200', 'Chicken Sandwich', 'menu_image/chicken.jpg', 12.00, 'chicken,tomato', 'plain'),
('NonVeg_7721', 'Veg Sandwich', 'menu_image/Veg.jpg', 18.00, 'veg,kheema', 'plain'),
('NonVeg_4862', 'Beef Sandwich', 'menu_image/Beef.jpg', 17.00, 'chicken,onion', 'plain'),
('NonVeg_8995', 'Ham Sandwich', 'menu_image/ham.jpg', 20.00, 'tandoori chicken,onion', 'plain');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` varchar(50) NOT NULL,
  `offer_name` varchar(50) NOT NULL,
  `items` varchar(50) NOT NULL,
  `off_on` int(11) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `mrp` double(10,2) NOT NULL,
  `offr_price` double(10,2) NOT NULL,
  `info` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `offer_name`, `items`, `off_on`, `img`, `mrp`, `offr_price`, `info`) VALUES
('Offer_7754', 'Bye 2 veg-pizza get 25% off', '2 veg pizzas', 50, 'menu_image/30922e5178d05ddf00b1509eebaed44f2.1.jpg', 400.00, 200.00, 'veg pizzs'),
('Offer_6428', 'Bye 5 non-pizza get 50% off', '5 non veg pizzas', 50, 'menu_image/66e05fcfe50f7a1a9b2e692eac5e0a9c3.jpg', 1200.00, 600.00, 'non-veg pizzas'),
('Offer_4215', 'Buy 3 Burger get 25% off', '3 burgers', 25, 'menu_image/0440a8d53d94bf8afecb6bc3600e5940dbur3.jpg', 300.00, 75.00, '3 burgers'),
('Offer_1891', 'Buy 3 Coco-Cola get 25% off', '3 colas', 25, 'menu_image/ce96caa3fd330f61d82894d7ce1ca8f9dfe80b9d9add7fbf6e985dff2da90148c10.jpg', 150.00, 37.50, '3 coco cola');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `cust_name` varchar(50) NOT NULL,
  `order_date` date NOT NULL,
  `order_time` time NOT NULL,
  `order_no` varchar(50) NOT NULL,
  `items` varchar(1000) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `gtotal` decimal(15,2) NOT NULL,
  `confirmed` int(11) NOT NULL,
  `confirmcode` int(11) NOT NULL,
  `flag` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `cust_name`, `order_date`, `order_time`, `order_no`, `items`, `qty`, `price`, `gtotal`, `confirmed`, `confirmcode`, `flag`) VALUES
(43, 'sweety', '2018-04-30', '05:09:09', 'ORDER_6924', 'Margherita Veg', 1, 20.00, 200.00, 0, 1, 0),
(44, 'sweety', '2018-04-30', '05:28:15', 'ORDER_7370', 'Mushroom Riot', 1, 30.00, 350.00, 0, 1, 0),
(45, 'sweety', '2018-04-30', '07:59:51', 'ORDER_6641', 'Margherita Veg', 2, 20.00, 400.00, 0, 1, 0),
(46, 'sneha', '2018-05-02', '02:32:17', 'ORDER_9706', 'Mushroom Riot', 1, 50.00, 350.00, 0, 1, 0),
(47, 'sneha', '2018-05-02', '02:32:17', 'ORDER_9706', 'Chicken Kheema', 1, 39.00, 349.00, 0, 1, 0),
(48, 'sneha', '2018-05-02', '02:32:17', 'ORDER_9706', 'Bye 2 veg-pizza get 25% off', 1, 20.00, 200.00, 0, 1, 0),
(49, 'sneha', '2018-05-02', '02:53:17', 'ORDER_2900', 'Mushroom Riot', 6, 30.00, 2100.00, 0, 1, 0),
(50, 'sneha', '2018-05-02', '02:53:17', 'ORDER_2900', 'chicken tikka,kheema', 5, 453.00, 2265.00, 0, 1, 0),
(51, 'sneha', '2018-05-02', '03:00:20', 'ORDER_8892', 'Mushroom Riot', 3, 350.00, 1050.00, 0, 1, 0),
(52, 'sneha', '2018-05-02', '03:00:20', 'ORDER_8892', 'chicken tikka,kheema', 6, 453.00, 2718.00, 0, 1, 0),
(53, 'sneha', '2018-05-02', '03:00:20', 'ORDER_8892', 'Bye 5 non-pizza get 50% off', 1, 600.00, 600.00, 0, 1, 0),
(54, 'sneha', '2018-05-02', '03:03:52', 'ORDER_6613', 'chicken tikka,kheema', 5, 453.00, 2265.00, 0, 1, 0),
(55, 'sneha', '2018-05-02', '03:03:52', 'ORDER_6613', 'Bye 5 non-pizza get 50% off', 1, 60.00, 600.00, 0, 1, 0),
(56, 'sneha', '2018-05-02', '03:06:39', 'ORDER_9703', 'chicken tikka,kheema', 6, 453.00, 2718.00, 1, 0, 1),
(57, 'sneha', '2018-05-02', '03:06:39', 'ORDER_9703', 'Bye 5 non-pizza get 50% off', 1, 60.00, 600.00, 1, 0, 1),
(58, 'sneha', '2018-05-02', '03:11:49', 'ORDER_2931', 'Mushroom Riot', 3, 350.00, 1050.00, 0, 1, 0),
(59, 'sneha', '2018-05-02', '03:11:49', 'ORDER_2931', 'Bye 5 non-pizza get 50% off', 1, 600.00, 600.00, 0, 1, 0),
(60, 'sneha', '2018-05-02', '03:13:48', 'ORDER_8669', 'Margherita Veg', 6, 20.00, 1200.00, 1, 0, 0),
(61, 'sneha', '2018-05-02', '03:23:49', 'ORDER_6514', 'Mushroom Riot', 6, 30.00, 2100.00, 1, 0, 0),
(62, 'sneha', '2018-05-02', '03:23:49', 'ORDER_6514', 'chicken tikka,kheema', 6, 453.00, 2718.00, 1, 0, 1),
(63, 'sneha', '2018-05-02', '03:23:49', 'ORDER_6514', 'Burger black juicy', 6, 12.00, 750.00, 1, 0, 1),
(64, 'sweety', '2018-05-02', '03:47:28', 'ORDER_4513', 'Mushroom Riot', 6, 350.00, 2100.00, 0, 1, 0),
(65, 'ash', '2019-05-21', '10:31:03', 'ORDER_3140', 'Mushroom Riot', 2, 350.00, 700.00, 0, 1, 0),
(66, 'kaviya', '2019-05-21', '03:00:54', 'ORDER_5323', 'Espresso', 2, 4.00, 8.00, 0, 1, 0),
(67, 'ash', '2019-05-24', '08:49:50', 'ORDER_8634', 'Espresso', 2, 4.00, 8.00, 0, 1, 0),
(68, 'ash', '2019-05-24', '02:24:48', 'ORDER_8483', 'Espresso', 2, 4.00, 8.00, 0, 1, 0),
(69, 'ash', '2019-05-24', '04:43:23', 'ORDER_5482', 'Espresso', 2, 4.00, 8.00, 0, 1, 0),
(70, 'ash', '2019-05-24', '04:52:57', 'ORDER_6516', 'Latte', 1, 10.00, 10.00, 0, 1, 0),
(71, 'ash', '2019-05-24', '04:57:41', 'ORDER_5821', 'Latte', 1, 10.00, 10.00, 0, 1, 0),
(72, 'ash', '2019-05-24', '05:01:56', 'ORDER_8797', 'Latte', 1, 10.00, 10.00, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `other_foods`
--

CREATE TABLE `other_foods` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `other_foods`
--

INSERT INTO `other_foods` (`id`, `name`, `image`, `price`) VALUES
('Ofood_1531', 'Coco-cola', 'menu_image/5b1653c91fea21a338ccd923c07fde09c8.jpg', 12.00),
('Ofood_4876', 'Sprite', 'menu_image/936fa46958113a1a467d3e78d670c4e6c4.jpg', 15.00),
('Ofood_4770', '7up', 'menu_image/b4bc9ebd215bb44ac089776caf876d447up.jpg', 17.00),
('Ofood_3991', 'Pepsi', 'menu_image/9ecb20ffe428f38294764ba3869a8562pepsi.jpg', 12.00),
('Ofood_4781', 'Strawberry Cake', 'menu_image/svake.jpg', 19.00),
('Ofood_3131', 'Vanilla Cake', 'menu_image/chocolate.jpg', 12.00);

-- --------------------------------------------------------

--
-- Table structure for table `reset_pass`
--

CREATE TABLE `reset_pass` (
  `email` varchar(50) NOT NULL,
  `otp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reset_pass`
--

INSERT INTO `reset_pass` (`email`, `otp`) VALUES
('qodor.info@gmail.com', 6135),
('kaviyasri7@gmail.com', 7777),
('qodor.info@gmail.com', 8437),
('qodor.info@gmail.com', 8593),
('swatikedar6@gmail.com', 8824),
('qodor.info@gmail.com', 9691),
('qodor.info@gmail.com', 9723);

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `name` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `area` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`name`, `number`, `email`, `username`, `password`, `area`, `address`) VALUES
('swati kedar', '1223352327', 'swatikedar6@gmail.com', 'sweety', 'swatiabcd', 'Belgaum', 'bgm'),
('snehal dhanagavade', '8147948795', 'qodor.info@gmail.com', 'sneha', '123456', 'vadgav', 'bgm'),
('Ash', '0452248043', 'ashchavan12@gmail.com', 'ash', 'RMIT12ash', 'vadgav', 'Australia'),
('kaviya', '9566113999', 'kaviyasri7@gmail.com', 'kaviya', 'theclimb77', 'vadgav', 'rmit');

-- --------------------------------------------------------

--
-- Table structure for table `veg_pizza`
--

CREATE TABLE `veg_pizza` (
  `id` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL,
  `info` varchar(500) NOT NULL,
  `flavour` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `veg_pizza`
--

INSERT INTO `veg_pizza` (`id`, `name`, `image`, `price`, `info`, `flavour`) VALUES
('Veg_7362', 'Espresso', 'menu_image/expresso.jpg', 10.00, 'Size - Small', '-Flavour-'),
('Veg_93', 'Assam Tea', 'menu_image/assamsmall.jpg', 8.00, 'Size - Medium', 'onion'),
('Veg_6386', 'Double espresso ', 'menu_image/doubleexpresso.jpg', 7.00, 'Size - Small', 'plain'),
('Veg_1832', 'Latte', 'menu_image/lattesmall.jpg', 10.00, 'Size - Large', 'plain'),
('Veg_8121', 'Cappuccino', 'menu_image/latte.jpg', 8.00, 'Size - Medium', 'plain'),
('Veg_5971', 'Cappuccino', 'menu_image/capps.jpg', 10.00, 'size- Large', 'plain'),
('Veg_92', 'Earl Gray', 'menu_image/earllarge.jpg', 12.00, 'Size - Large', 'onion'),
('Veg_1742', 'Long black', 'menu_image/longblack.jpg', 12.00, 'Size - Medium', 'plain'),
('Veg_2641', 'Long black', 'menu_image/longblacklarge.jpg', 13.00, 'size- Large', 'plain'),
('Veg_7696', 'Hot chocolate ', 'menu_image/hotchoclate.jpg', 9.00, 'Size - Medium', 'plain'),
('Veg_91', 'Earl Gray', 'menu_image/earl.jpg', 10.00, 'Size- Medium', 'onion'),
('Veg_2773', 'Hot chocolate ', 'menu_image/hotchocolatelarge.jpg', 12.00, 'size- Large', 'plain'),
('Veg_99', 'Green Tea', 'menu_image/greenlarge.jpg', 8.00, 'Size - Large', 'onion'),
('Veg_1996', 'Mint Tea', 'menu_image/mintsmall.jpg', 4.00, 'Size - Medium ', 'onion'),
('Veg_98', 'Green Tea', 'menu_image/greensmall.jpg', 6.00, 'Size - Medium', 'onion'),
('Veg_94', 'Assam Tea', 'menu_image/assamlarge.jpg', 9.00, 'Size - Large', 'onion'),
('Veg_1997', 'Mint Tea', 'menu_image/mintlarge.jpg', 11.00, 'Size - medium', '-Flavour-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_reg`
--
ALTER TABLE `admin_reg`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cust_ship_details`
--
ALTER TABLE `cust_ship_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `non_veg_pizza`
--
ALTER TABLE `non_veg_pizza`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `other_foods`
--
ALTER TABLE `other_foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reset_pass`
--
ALTER TABLE `reset_pass`
  ADD PRIMARY KEY (`otp`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `veg_pizza`
--
ALTER TABLE `veg_pizza`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cust_ship_details`
--
ALTER TABLE `cust_ship_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
