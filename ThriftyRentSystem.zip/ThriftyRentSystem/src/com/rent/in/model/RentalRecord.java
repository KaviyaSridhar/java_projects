package com.rent.in.model;
public class RentalRecord {

    private final String rentalRecordId;
    private final String cId;
    private final DateTime dateOfRent;
    private final DateTime estimatedDateOfReturn;
    private DateTime returnDate;
    private Double actualFee;
    private Double lateFee;
    
    public RentalRecord(String rentalRecordId, String cId,DateTime dateOfRent, DateTime estimatedDateOfReturn, DateTime returnDate, Double actualFee, Double lateFee) {
        this.rentalRecordId = rentalRecordId;
        this.cId = cId;
        this.dateOfRent = dateOfRent;
        this.estimatedDateOfReturn = estimatedDateOfReturn;
        this.returnDate = returnDate;
        this.actualFee = actualFee;
        this.lateFee = lateFee;
    }
    
    public RentalRecord(String rentalRecordId, String cId,DateTime dateOfRent, DateTime estimatedDateOfReturn) {
        this.rentalRecordId = rentalRecordId;
        this.cId = cId;
        this.dateOfRent = dateOfRent;
        this.estimatedDateOfReturn = estimatedDateOfReturn;
    }

    
    
    public String getCId() {
        return cId;
    }

    public String getRentalRecordId() {
        return rentalRecordId;
    }

    public DateTime getDateOfRent() {
        return dateOfRent;
    }
    
    public Double getLateFee() {
        return lateFee;
    }
    
    public DateTime getEstimatedDateOfReturn() {
        return estimatedDateOfReturn;
    }

    public DateTime getRetunDate() {
        return returnDate;
    }

    public void setRetunDate(DateTime retunDate) {
        this.returnDate = retunDate;
    }

    public Double getFare() {
        return actualFee;
    }

    public void setFare(Double actualFee) {
        this.actualFee = actualFee;
    }

    public void setLateFee(Double late_Fee) {
        this.lateFee = late_Fee;
    }

    @Override
    public String toString() {
        String returnString = "none:none:none";
        if (returnDate != null)
        	returnString = returnDate.toDbString() + ":" + actualFee.toString() + ":" + lateFee.toString();
        return rentalRecordId + ":" + cId + ":" + dateOfRent.toDbString() + ":" + estimatedDateOfReturn.toDbString() + ":" + returnString;
    }
}
