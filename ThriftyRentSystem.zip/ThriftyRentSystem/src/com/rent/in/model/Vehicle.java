package com.rent.in.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Types;
import java.nio.file.Path;
import java.nio.file.Paths;
import javafx.scene.image.Image;
import com.rent.in.model.exception.IdExistsException;
import com.rent.in.model.exception.InvalidIdException;
import com.rent.in.model.exception.NotAvailableException;


public abstract class Vehicle {
    public static final ArrayList<Vehicle> vechicleList = new ArrayList<>(50);
    private final Map<String, RentalRecord> rentalRecordList = new HashMap<>();
    public static String vehicleAvailable = "Available", vehicleRented = "Rented", vehicleUnderMaintenance = "Maintenance";
    private String vehicleId;
    private String yearOfManufacture;
    private String make;
    private String model;
    private int seatNumber;
    private String vehicleType;
    private String vehicleStatus;
    
    //constructor
    public Vehicle() { }
    
    public Vehicle(String vehicle_Id, String manufacture_Date, String vehicle_Maker, String vehicle_Model, int numberOfPassanger, String type, String vehicle_Status) {
        super();
        this.vehicleId = vehicle_Id;
        this.yearOfManufacture = manufacture_Date;
        this.make = vehicle_Maker;
        this.model = vehicle_Model;
        this.seatNumber = numberOfPassanger;
        this.vehicleType = type;
        this.vehicleStatus = vehicle_Status;
    }
    
    //accessors and mutators
    
    public String getIdOfVehicle() {
        return vehicleId;
    }
    
    public String getStatusOfVehicle() {
        return vehicleStatus;
    }
    
    public String getVehicleType() {
        return vehicleType;
    }
    
    public String getYear() {
        return yearOfManufacture;
    }
    
    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }
    
    public int getSeatNumber() {
        return seatNumber;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public void setManufactureYear(String manufactureYear) {
        this.yearOfManufacture = manufactureYear;
    }
    
    public void setNumOfSeats(int numberOfPassanger) {
        seatNumber = numberOfPassanger;
    }
    
    public void setVehicleMake(String vehicleMaker) {
        make = vehicleMaker;
    }

    public void setType(String type) {
        this.vehicleType = type;
    }

    public void setVehicleModel(String model) {
        this.model = model;
    }

    public Collection<RentalRecord> getRecords() {
        return rentalRecordList.values();
    }
    
    //getting pending records rent
    private RentalRecord getPendingRecord() {
        for (RentalRecord record : rentalRecordList.values())
            if (record.getRetunDate() == null)
                return record;
        return null;
    }
    
    //setting the vehicle status of the car
    public void setVehicleStatus(String vehicleStatus) throws ClassNotFoundException, SQLException {
        //updating the vechicle status to the database
    	this.vehicleStatus = vehicleStatus;
        databaseVechicleStatusUpdate();
    }
    
    //if record id already exists
    public RentalRecord getRecord(String rentalRecordId) throws InvalidIdException {
        for (RentalRecord record : rentalRecordList.values()) 
        	if(record.getRentalRecordId().equals(rentalRecordId)) 
        		return record;
        throw new InvalidIdException();
    }
    
    //using put to store the rental record in hashmap
    public void storeRentalRecord(RentalRecord r) {
        rentalRecordList.put(r.getRentalRecordId(), r);
    }
        
    
    //Id invalid exceptions
    public static Vehicle getVehicle(String vehicleId) throws InvalidIdException {
        for (Vehicle v : vechicleList) 
        if(v.getIdOfVehicle().equals(vehicleId)) return v;
        throw new InvalidIdException();
    }
    
    
    public abstract void feeCalculatorOnVechicleReturn(RentalRecord records, DateTime dateOfReturn);
    public abstract double fareCalculate(Date dateOfRent, long numOfDays);
    public abstract double threeDayRent();
    
    private void databaseVechicleStatusUpdate() throws ClassNotFoundException, SQLException {
        //database connect and update vechicle Id and Vechicle status
    	Connection conn = Database.connect();
        PreparedStatement statement = conn.prepareStatement("update vehicles set vehicle_status = ? where vehicle_id = ?");
        statement.setString(1, getStatusOfVehicle());
        statement.setString(2, getIdOfVehicle());
        statement.execute();
    }
    
    private static void addVehicleToDatabase(Vehicle v) throws ClassNotFoundException, SQLException {
        Connection connection = Database.connect();
        PreparedStatement statement = connection.prepareStatement("insert into vehicles values (?,?,?,?,?,?,?,?)");
        //setting the vechicle string details
        statement.setString(1, v.getIdOfVehicle());
        statement.setString(2, v.getVehicleType());
        statement.setString(3, v.getMake());
        statement.setString(4, v.getModel());
        statement.setString(5, v.getYear());
        statement.setInt(6, v.getSeatNumber());
        statement.setString(7, v.getStatusOfVehicle());
        // if the vehicle is of type van
        if (v instanceof Van)
            statement.setString(8, null);
        else
            statement.setString(8, null);
        //execute  statement
        statement.execute();
    }
    
  //Adding vehicle to the system 
    public static void addingVehicleToApplication(String id, String year, String make, String model, int seatNumber, String type, String vehicleStatus) throws IdExistsException, InvalidIdException, ClassNotFoundException, SQLException {
        //if  the vehicle starts with c_ or v_ check for duplicate records
    	if (id.toUpperCase().startsWith("V_") || id.toUpperCase().startsWith("C_")) {
            for (Vehicle v : vechicleList) 
            	if (v.getIdOfVehicle().equals(id))
                throw new IdExistsException();
            Vehicle vehicle = null;
            if (id.toUpperCase().startsWith("C_")) 
            	//adding record
            	vehicle = new Car(id, year, make, model, seatNumber, vehicleAvailable);
            else if (id.toUpperCase().startsWith("V_")) 
            	//adding record to van
            	vehicle = new Van(id, year, make, model, seatNumber, vehicleAvailable, null);
            else throw new InvalidIdException();
            //add vechile to the list
            vechicleList.add(vehicle);
            //add vehicle to the database
            addVehicleToDatabase(vehicle);
        } 
    }
 // This Method is called to return vehicle image
    public Image getVehicleImage() {
        Image image = new Image(getPathOfVehicleImage());
        if (image.isError()) 
        //if there is an image error display a default image
        return new Image(getClass().getResourceAsStream("/com/rent/in/view/default_img.png"));
        //else we return the image
        else 
        	return image;
    }
    public static String pathForImageVehile(String make, String model) {
        return String.format("file:images/%s_%s.jpg", make.toLowerCase().replace(" ", "_"), model.toLowerCase().replace(" ", "_"));
    }
    
    public String getPathOfVehicleImage() {
        return pathForImageVehile(getMake(), getModel());
    }
    
    
    public static Path pathTwoForImageVehile(String make, String model) {
        return Paths.get(String.format("images/%s_%s.jpg", make.toLowerCase().replace(" ", "_"), model.toLowerCase().replace(" ", "_")));
    }

    //This Method is Called to rent Vehilces(Car or Van)
    public void rent(String cID, DateTime dateOfRent, int noOfDays) throws NotAvailableException, InvalidIdException, ClassNotFoundException, SQLException {
        String rId;
        
        if (getStatusOfVehicle().equals(vehicleAvailable))
        {
        	rId = String.format("%s_%s_%s", vehicleId, cID, dateOfRent.getEightDigitDate());
             DateTime estimatedDateOfReturn = new DateTime(dateOfRent, noOfDays);
             RentalRecord r = new RentalRecord(rId, cID, dateOfRent, estimatedDateOfReturn);
             storeRentalRecord(r);
             setVehicleStatus(vehicleRented);
             updateRentDatabase(r);
        }
            
        else {
        	throw new NotAvailableException();
        }
    }
    
    private void updateRentDatabase(RentalRecord record) throws ClassNotFoundException, SQLException {
        Connection connect = Database.connect();
        PreparedStatement statement = connect.prepareStatement("insert into rentals (record_id, customer_id, rent_date, estimated_return) values (?,?,?,?)");
        statement.setString(4, record.getEstimatedDateOfReturn().getDbDate());
        statement.setString(3, record.getDateOfRent().getDbDate());
        statement.setString(2, record.getCId());
        statement.setString(1, record.getRentalRecordId());
        statement.execute();
    }
    
    // This Method is called to return vehicle
    public void returningVehicle(DateTime returnDate) throws InvalidIdException, ClassNotFoundException, SQLException {
        RentalRecord record = getPendingRecord();
        feeCalculatorOnVechicleReturn(record, returnDate);
        setVehicleStatus(vehicleAvailable);
        updateDataBaseOnReturn(record);
    }
    
    private void updateDataBaseOnReturn(RentalRecord r) throws ClassNotFoundException, SQLException {
        Connection c = Database.connect();
        PreparedStatement statement = c.prepareStatement("update rentals set actual_return = ?, rental_fee = ?, late_fee = ? where record_id = ?");
        statement.setString(1, r.getRetunDate().getDbDate());
        statement.setDouble(2, r.getFare());
        statement.setDouble(3, r.getLateFee());
        statement.setString(4, r.getRentalRecordId());
        statement.execute();
    }

    public static void ImportVehicle(String data) throws ClassNotFoundException, SQLException {
        String[] vehicleData = data.split("\n");
        String[] vehicle = vehicleData[0].split(":");
        Connection c = Database.connect();
        PreparedStatement statement = c.prepareStatement("insert into vehicles values (?,?,?,?,?,?,?,?)");
        statement.setString(1, vehicle[0]);
        statement.setString(2, vehicle[1]);
        statement.setString(3, vehicle[2]);
        statement.setString(4, vehicle[3]);
        statement.setString(5, vehicle[4]);
        statement.setInt(6, Integer.parseInt(vehicle[5]));
        statement.setString(7, vehicle[6]);
        statement.setString(8, vehicle[7].equals("none") ? null : vehicle[7]);
        statement.execute();
        
        for (int i = 1; i < vehicleData.length; i++) {
            String[] r = vehicleData[i].split(":");
            statement = c.prepareStatement("insert into rentals (record_id, customer_id, rent_date, estimated_return, actual_return, rental_fee, late_fee) values (?,?,?,?,?,?,?)");
            statement.setString(1, r[0]);
            statement.setString(2, r[1]);
            statement.setString(3, r[2]);
            statement.setString(4, r[3]);
            //if actual date is not known other values are set to null
            if (r[4].equals("none")) {
                statement.setNull(5, Types.VARCHAR);
                statement.setNull(6, Types.DOUBLE);
                statement.setNull(7, Types.DOUBLE);
            } else {
            	// else we update the other late fee and actual fee
                statement.setString(5, r[4]);
                statement.setDouble(6, Double.parseDouble(r[5]));
                statement.setDouble(7, Double.parseDouble(r[6]));
            }
            //execute statement
            statement.execute();
        }
    }
    
    public static ArrayList<String> GetAllMakes() throws ClassNotFoundException, SQLException {
        Connection c = Database.connect();
        PreparedStatement statement = c.prepareStatement(
            "select distinct vehicle_maker from vehicles"
        );
        ArrayList<String> makes = new ArrayList<>();
        ResultSet resultset = statement.executeQuery();
        while (resultset.next()) {
        	makes.add(resultset.getString(1));
        }
        return makes;
    }
    //loading from the database ordered by vehicle id
    public static void ImportFromDatabase() throws ClassNotFoundException, SQLException {
        vechicleList.clear();
        Connection c = Database.connect();
        PreparedStatement statement = c.prepareStatement(
            "select * from vehicles order by vehicle_id"
        );
        ResultSet resultset = statement.executeQuery();
        while (resultset.next()) {
            String type = resultset.getString("vehicle_type");
            Vehicle v = type.equals("Car") ? 
                    new Car(resultset.getString("vehicle_id"),resultset.getString("manufacture_year"),resultset.getString("vehicle_maker"),resultset.getString("vehicle_model"),resultset.getInt("no_of_seats"),resultset.getString("vehicle_status")) : 
                    new Van(resultset.getString("vehicle_id"),resultset.getString("manufacture_year"),resultset.getString("vehicle_maker"),resultset.getString("vehicle_model"),resultset.getInt("no_of_seats"),resultset.getString("vehicle_status"),
                    new DateTime(resultset.getString("last_maintenance"))) ;
            fetchRecordList(v);
            vechicleList.add(v);
        }
    }
    
    private static void fetchRecordList(Vehicle vehicle) throws ClassNotFoundException, SQLException {
        vehicle.rentalRecordList.clear();
        Connection connect = Database.connect();
        PreparedStatement statement = connect.prepareStatement(
            "select * from rentals where record_id like '" + vehicle.getIdOfVehicle() + "%' order by case when actual_return is null then 1 else 0 end, rent_date"
        );
        ResultSet resultset = statement.executeQuery();
        while (resultset.next()) {
            DateTime dateOfReturn = null;
            Double lateFee = null;
            Double returnFee = null;

            try {
            	//if date of return was null
            	dateOfReturn = new DateTime(resultset.getString("actual_return"));
                if (resultset.wasNull()) 
                dateOfReturn = null;
                //if return fee was set to null
                returnFee = resultset.getDouble("rental_fee");
                if (resultset.wasNull()) 
                returnFee = null;
                //if late fee is null
                lateFee = resultset.getDouble("late_fee");
                if (resultset.wasNull()) 
                lateFee = null;
            } catch (SQLException ex) { }
            
            RentalRecord r = new RentalRecord(resultset.getString("record_id"), resultset.getString("customer_id"), new DateTime(resultset.getString("rent_date")), new DateTime(resultset.getString("estimated_return")), dateOfReturn, returnFee, lateFee);
            vehicle.storeRentalRecord(r);
        }
    }
    @Override
    public String toString() {
    	String records = "";
        String addRecords = "none";
        //if the vechicle is of instance van
        if (this instanceof Van) 
        //add maintenance date to the string in database
        addRecords = ((Van)this).getMaintanenceDate().toDbString();
        //adding the maintenance record details to the string
        records = rentalRecordList.values().stream().map((r) -> r.toString() + "\n").reduce(records, String::concat);
        return vehicleId + ":" + vehicleType + ":" + make + ":" + model + ":" + yearOfManufacture + ":" + seatNumber + ":" + vehicleStatus + ":" + addRecords + "\n" + records + "\n";
    }
}
