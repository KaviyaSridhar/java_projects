package com.rent.in.model.exception;

public class IdExistsException extends Exception {
    private String message = "Duplicate Id enter new Id";

    @Override
    public String getMessage() {
        return message;
    }
    
}