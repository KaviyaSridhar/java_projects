package com.rent.in.model.exception;

public class InvalidIdException extends Exception {
    private String message = "Invalid Id entered";

    @Override
    public String getMessage() {
        return message;
    }
    
}