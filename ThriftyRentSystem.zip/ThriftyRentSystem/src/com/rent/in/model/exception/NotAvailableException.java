package com.rent.in.model.exception;

public class NotAvailableException extends Exception {
    private String message = "Vechicle currently not available";

    @Override
    public String getMessage() {
        return message;
    }
    
}