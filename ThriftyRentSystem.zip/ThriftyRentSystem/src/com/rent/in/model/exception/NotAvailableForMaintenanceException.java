package com.rent.in.model.exception;

public class NotAvailableForMaintenanceException extends Exception {
    private String message = "Vehicle not available for maintenance";

    @Override
    public String getMessage() {
        return message;
    }
    
}