package com.rent.in.model.exception;

public class NotAvailableForMaintenanceCompletionException extends Exception {
    private String message = "Vechicle not available for maintenace completion";

    @Override
    public String getMessage() {
        return message;
    }
    
}