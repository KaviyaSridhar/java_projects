package com.rent.in.model.exception;

public class MaintenanceScheduleException extends Exception {
    private String message = "Van Maintenance needs to be scheduled before the return date";

    @Override
    public String getMessage() {
        return message;
    }
    
}