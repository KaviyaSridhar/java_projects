package com.rent.in.model;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {

    public static Connection connect() throws ClassNotFoundException, SQLException {
        Class.forName("org.hsqldb.jdbc.JDBCDriver");
        return DriverManager.getConnection("jdbc:hsqldb:file:database/RentalDatabase", "SA", "");
    }
    
    public static void prepare() throws ClassNotFoundException, SQLException {
        if (!tablesExist()) {
            createTables();
            initialRecords();
        }
    }

    private static boolean tablesExist() throws ClassNotFoundException, SQLException {
        Connection c = connect();
        DatabaseMetaData dbm = c.getMetaData();
        ResultSet tables = dbm.getTables(null, null, "vehicles".toUpperCase(), null);
        return tables != null && tables.next();
    }

    private static void createTables() throws ClassNotFoundException, SQLException {
        if (!tablesExist()) {
            Connection c = connect();
            PreparedStatement stmt;
            stmt = c.prepareStatement(
                "create table vehicles ("
                + "vehicle_id       varchar(64), "
                + "vehicle_type     varchar(4), "
                + "vehicle_maker    varchar(32), "
                + "vehicle_model    varchar(32), "
                + "manufacture_year varchar(4), "
                + "no_of_seats      int, "
                + "vehicle_status   varchar(16), "
                + "last_maintenance date"
                + ");"
            );
            stmt.execute();
            
            stmt = c.prepareStatement(
                "create table rentals ("
                + "record_id        varchar (128), "
                + "customer_id      varchar (128), "
                + "rent_date        date, "
                + "estimated_return date, "
                + "actual_return    date, "
                + "rental_fee       numeric, "
                + "late_fee         numeric"
                + ");"
            );
            stmt.execute();
        }
    }

    private static void initialRecords() throws ClassNotFoundException, SQLException {
        Connection c = connect();
        PreparedStatement stmt = c.prepareStatement(
            "insert into vehicles values "
            + "('c_01','Car','Audi',            'TT',           '2017',4, 'Available',null ), "
            + "('c_02','Car','Audi',            'Q5',           '2017',4, 'Available',null ), "
            + "('c_03','Car','Bentley',         'Continental',  '2017',4, 'Available',null ), "
            + "('c_04','Car','Citoren',         'C3',           '2017',4, 'Available',null ), "
            + "('c_05','Car','Dodge',           'Challenger',   '2017',7, 'Available',null ), "
            + "('c_06','Car','Honda',           'Accord',       '2017',4, 'Available',null ), "
            + "('c_07','Car','Maserati',        'Levante',      '2017',4, 'Available',null ), "
            + "('c_08','Car','Mercedes Benz',   'E Class',      '2017',4, 'Available',null ), "
            + "('c_09','Car','Toyota',          'FJ Cruiser',   '2017',7, 'Available',null ), "
            + "('c_10','Car','Volvo',           'XC 40',        '2017',7, 'Available',null ), "

            + "('v_01','Van','Ford',            'Transit',      '2017',15,'Available',now()), "
            + "('v_02','Van','Hyundai',         'Grand Starex', '2017',15,'Available',now()), "
            + "('v_03','Van','Mercedes Benz',   'Metris',       '2017',15,'Available',now()), "
            + "('v_04','Van','Mercedes Benz',   'Sprinter',     '2017',15,'Available',now()), "
            + "('v_05','Van','Renault',         'Trafic',       '2017',15,'Available',now())  "
        );
        stmt.execute();
    }
    
    public static void clearRecords() throws ClassNotFoundException, SQLException {
        Connection c = connect();
        PreparedStatement stmt;
        
        stmt = c.prepareStatement("delete from rentals");
        stmt.execute();
        
        stmt = c.prepareStatement("delete from vehicles");
        stmt.execute();
    }
}
