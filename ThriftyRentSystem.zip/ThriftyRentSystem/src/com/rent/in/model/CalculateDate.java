package com.rent.in.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

public class CalculateDate {
    
	//to calculate day
	public static String calculateDay(Date startDate) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
        String DayFromDate = simpleDateFormat.format(startDate);
        return DayFromDate;
    }
	
	//to estimate the calculated date
    public static Date calculateEstimateDate(Date startDate, int noOfDays) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar calender = Calendar.getInstance();
        calender.setTime(startDate);
        calender.add(Calendar.DAY_OF_MONTH, noOfDays);
        return calender.getTime();
    }

    
}
