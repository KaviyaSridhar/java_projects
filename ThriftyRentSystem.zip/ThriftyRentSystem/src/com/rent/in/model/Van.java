package com.rent.in.model;

import static com.rent.in.model.Vehicle.vehicleAvailable;
import static com.rent.in.model.Vehicle.vehicleUnderMaintenance;
import com.rent.in.model.exception.InvalidIdException;
import com.rent.in.model.exception.MaintenanceScheduleException;
import com.rent.in.model.exception.NotAvailableForMaintenanceCompletionException;
import com.rent.in.model.exception.NotAvailableForMaintenanceException;
import java.sql.SQLException;
import java.util.Date;
import java.util.concurrent.TimeUnit;
//vehicle class

public class Van extends Vehicle {

    public static final double VECHICLERENTFEE = 235;
    public static final double LATEFEE = 299;
    private DateTime maintenanceDate;

    public Van() { }

    public Van(String vehicleId, String manufactureYear, String vehicleMaker, String model, int seatNumber, String vehicleStatus, DateTime maintenanceDate) {
        super(vehicleId, manufactureYear, vehicleMaker, model, seatNumber, "Van", vehicleStatus);
        this.maintenanceDate = maintenanceDate;
    }
    
    public DateTime getMaintanenceDate() {
        return maintenanceDate;
    }

    public void setMaintanenceDate(DateTime maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }
    
    @Override
    public double fareCalculate(Date dateOfRent, long daysCount) {
        return VECHICLERENTFEE * daysCount;
    }

    // Perform Maintenance
    public void performMaintenance() throws NotAvailableForMaintenanceException, InvalidIdException, ClassNotFoundException, SQLException {
        if (!getStatusOfVehicle().equals(vehicleAvailable)) 
        	//vehicle not available o put it under maintenance
            throw new NotAvailableForMaintenanceException();
        else 
            setVehicleStatus(vehicleUnderMaintenance);
    }
    // Complete the Maintenance
    public void completeMaintenance(DateTime completionDate) throws NotAvailableForMaintenanceCompletionException, ClassNotFoundException, SQLException {
        if (!getStatusOfVehicle().equals(vehicleUnderMaintenance)) 
            throw new NotAvailableForMaintenanceCompletionException();
        else {
            setMaintanenceDate(completionDate);
            setVehicleStatus(vehicleAvailable);
        }
    }
    // maintenance date check before renting
    public void validateMaintenance(Date maintenanceDate, Date dateOfRent, int NumOfDays) throws MaintenanceScheduleException {
        Date nextMainatinceDate = CalculateDate.calculateEstimateDate(maintenanceDate, 12);
        Date estimateReturnDate = CalculateDate.calculateEstimateDate(dateOfRent, NumOfDays);
        //throwing maintenance schedule exception
        if (estimateReturnDate.compareTo(nextMainatinceDate) > 0) 
            throw new MaintenanceScheduleException();
    }
    public boolean validateBooking(int daysCount) {
        if (daysCount >= 1) {
            return true;
        }
        else
        return false;
    }

    // Calculating the actualFee for van
    @Override
    public void feeCalculatorOnVechicleReturn(RentalRecord r, DateTime dateOfReturn) {
        DateTime estimatedDateOfReturn = r.getEstimatedDateOfReturn();
        r.setRetunDate(estimatedDateOfReturn);
        long calculate;
        long totalDays = 0;
        long daysLate = 0;
        double vechiclefee = 0.0;
        double lateFee = 0;
        
        if (dateOfReturn.compareTo(estimatedDateOfReturn) > 0) {
        	calculate = estimatedDateOfReturn.getTime() - r.getDateOfRent().getTime();
        	totalDays = TimeUnit.DAYS.convert(calculate, TimeUnit.MILLISECONDS);
            
            calculate = dateOfReturn.getTime() - estimatedDateOfReturn.getTime();
            daysLate = TimeUnit.DAYS.convert(calculate, TimeUnit.MILLISECONDS);
        	
        } else {
        	calculate = dateOfReturn.getTime() - r.getDateOfRent().getTime();
        	totalDays = TimeUnit.DAYS.convert(calculate, TimeUnit.MILLISECONDS);
        }
        
        vechiclefee = VECHICLERENTFEE * totalDays;
        r.setFare(vechiclefee);
        vechiclefee = LATEFEE * daysLate;
        r.setLateFee(vechiclefee);
        
       
    }
    
    

    
    
    

    @Override
    public double threeDayRent() {
        return VECHICLERENTFEE * 3;
    }
}