package com.rent.in.model;

import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.TimeUnit;


//Car Class
public class Car extends Vehicle {

    
    double rentCar;
    //rent for three and 4 seater
    double fourSeats = 78;
    double sevenSeats = 113;
    static String[] twoDayMinimum = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"};
    static String[] threeDayMinimum = {"Friday", "Saturday"};
    
    //constructor
    public Car() {
    }
    
    //constructor
    public Car(String vehicleId, String manufactureYear, String vehicleMaker, String model,int seatNumber, String vehicleStatus) {
        super(vehicleId, manufactureYear, vehicleMaker, model, seatNumber, "Car", vehicleStatus);
    }

    // Calculating the actualFee for car
    @Override
    public void feeCalculatorOnVechicleReturn(RentalRecord r, DateTime dateOfReturn) {
    	
        double fee = 0.0;
        double lateFee = 0.0;
        long calculate;
        long total = 0;
        long late_days = 0;
    	DateTime estimatedDateofReturn = r.getEstimatedDateOfReturn();
        r.setRetunDate(dateOfReturn);
        
        //if the actual date of return is greater than the estimated return date
        if (dateOfReturn.compareTo(estimatedDateofReturn) > 0) {
        	calculate = estimatedDateofReturn.getTime() - r.getDateOfRent().getTime();
            total= TimeUnit.DAYS.convert(calculate, TimeUnit.MILLISECONDS);   
            calculate = dateOfReturn.getTime() - estimatedDateofReturn.getTime();
            late_days = TimeUnit.DAYS.convert(calculate, TimeUnit.MILLISECONDS);
        	
        } 
        else {
        	calculate = dateOfReturn.getTime() - r.getDateOfRent().getTime();
            total = TimeUnit.DAYS.convert(calculate, TimeUnit.MILLISECONDS);
        }
        
        fee = (getSeatNumber() == 4 ? 78 : 113) * total;
        r.setFare(new Double(fee));
        lateFee = (getSeatNumber() == 4 ? 78 : 113) * 1.25 * late_days; 
        r.setLateFee(new Double(lateFee));
    }
    

    @Override
    public double fareCalculate(Date date, long days) {
    	
        String dayOne = CalculateDate.calculateDay(date);
        rentCar = 0.0;
        //if id starts with car
        if (getIdOfVehicle().toUpperCase().startsWith("C_")) {
            if (days < 15 && ((Arrays.asList(threeDayMinimum).contains(dayOne) && days >= 3) || (Arrays.asList(twoDayMinimum).contains(dayOne) && days >= 2))) 
            {
            	rentCar = (getSeatNumber() == 7 ? sevenSeats : fourSeats) * days;
            }
        }
        return rentCar;
    }

    
    @Override
    public double threeDayRent() {
    	if(getSeatNumber() == 4)
    		return 78*3;
    	else
    		return 113*3;
        
    }
}
