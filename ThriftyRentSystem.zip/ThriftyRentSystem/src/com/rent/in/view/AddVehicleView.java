package com.rent.in.view;

import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


public abstract class AddVehicleView extends VBox {
	//label and combo box for vechicle ID
    protected final Label vechicleId;
    protected final TextField jtxId;
	//label and combo box for vehicle type
    protected final Label vechicleLabelType;
    protected final ComboBox jfxType;
    //label and combo box for vechicle model
    protected final Label vechicleModel;
    protected final TextField modelText;
    //vBox and buttons 
    protected final VBox vBoxSaveBtn;
    protected final Button saveBtn;
    protected final Button addImageBtn;
    protected final Button canelButton;
    //label and combo box for vechicle make
    protected final Label carMakeLabel;
    protected final TextField textCarMake;
    //label and combobox for number of seats
    protected final Label carSeatLabel;
    protected final ComboBox jfxVechicleSeats;
    //label and comn=bo box for year of manufacture
    protected final Label yearLabel;
    protected final TextField yearText;

    public AddVehicleView() {
    	//initializing the vechicle views 
    	vechicleId = new Label();
        jtxId = new TextField();
        vechicleModel = new Label();
        modelText = new TextField();
        vBoxSaveBtn = new VBox();
        saveBtn = new Button();
        canelButton = new Button();
        addImageBtn = new Button();
        carMakeLabel = new Label();
        textCarMake = new TextField();
        vechicleLabelType = new Label();
        jfxType = new ComboBox();
        carSeatLabel = new Label();
        jfxVechicleSeats = new ComboBox();
        yearLabel = new Label();
        yearText = new TextField();
        
        //setting width and height for add new vechicle
        setSpacing(10);
        setMaxHeight(800);
        setMinHeight(800);
        setPrefHeight(800);
        setMaxWidth(450);
        setMinWidth(450);
        setPrefWidth(450);
        
        //addImageBtn.setStyle("-fx-background-color: #2f3c7e;");
        //addImageBtn.setStyle( "-fx-text-fill: white");
        addImageBtn.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        
        //setting the width, height, text for the addImage button
        addImageBtn.setText("Add Image");
        addImageBtn.setPrefWidth(140);
        addImageBtn.setPrefHeight(30);
        addImageBtn.setAlignment(javafx.geometry.Pos.CENTER);
 
        //setting text, width, height for vechicle type
        vechicleLabelType.setText("Vechicle Type");
        jfxType.setPrefHeight(27);
        jfxType.setPrefWidth(500);
        
        //setting the seats text,width,height,margin 
        carSeatLabel.setText("Number of Seats");
        jfxVechicleSeats.setPrefWidth(500);
        jfxVechicleSeats.setPrefHeight(27);
        VBox.setMargin(carSeatLabel, new Insets(15, 0, 0, 0));
        
        //margin and alignment for save button
        vBoxSaveBtn.setAlignment(javafx.geometry.Pos.CENTER);
        VBox.setMargin(vBoxSaveBtn, new Insets(15, 0, 0, 0));
        
        // setting text and width for text fields
        vechicleId.setText("Vechicle ID");
        vechicleModel.setText("Vechicle Model");
        carMakeLabel.setText("Vechicle Make");
        yearLabel.setText("Vechicle Year of manufacture");
        VBox.setMargin(vechicleId, new Insets(15, 0, 0, 0));
        VBox.setMargin(vechicleModel, new Insets(15, 0, 0, 0));
        VBox.setMargin(carMakeLabel, new Insets(15, 0, 0, 0));
        VBox.setMargin(yearLabel, new Insets(15, 0, 0, 0));
        
        //setting the button save
        saveBtn.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        saveBtn.setText("Save");
        saveBtn.setPrefWidth(140);
        saveBtn.setPrefHeight(30);
        saveBtn.setAlignment(javafx.geometry.Pos.CENTER);
        VBox.setMargin(saveBtn, new Insets(15, 0, 0, 0));
       
        
        //setting the alignment,width,height,text for cancel button
        canelButton.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        canelButton.setText("Cancel");
        canelButton.setPrefWidth(140);
        canelButton.setPrefHeight(30);
        canelButton.setAlignment(javafx.geometry.Pos.CENTER);
        VBox.setMargin(canelButton, new Insets(15, 0, 0, 0));
        setPadding(new Insets(15));
        
        
        //calling getChildren to add element to the window
        
        //vechicle type
        getChildren().add(vechicleLabelType);
        getChildren().add(jfxType);
        //vechicle id
        getChildren().add(vechicleId);
        getChildren().add(jtxId);
        //vehicle seats
        getChildren().add(carSeatLabel);
        getChildren().add(jfxVechicleSeats);
        //vechicle model
        getChildren().add(vechicleModel);
        getChildren().add(modelText);
        //vechicle year
        getChildren().add(yearLabel);
        getChildren().add(yearText);
        //vechicle make
        getChildren().add(carMakeLabel);
        getChildren().add(textCarMake);
        //button for adding image
        vBoxSaveBtn.getChildren().add(addImageBtn);
        //cancel button
        vBoxSaveBtn.getChildren().add(canelButton);
        //save button 
        vBoxSaveBtn.getChildren().add(saveBtn);
        getChildren().add(vBoxSaveBtn);
    }
}
