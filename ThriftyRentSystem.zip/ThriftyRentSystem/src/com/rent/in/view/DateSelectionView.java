package com.rent.in.view;

import javafx.scene.control.DatePicker;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;


public abstract class DateSelectionView extends VBox {
    
    protected final DatePicker datePickerDateReturn;
    protected final VBox vBoxSaveBtn;
    protected final Button saveBtn;
    protected final Button canelButton;
    protected final Label labelDatePickerDateReturn;

    public DateSelectionView() {
        labelDatePickerDateReturn = new Label();
        datePickerDateReturn = new DatePicker();
        vBoxSaveBtn = new VBox();
        saveBtn = new Button();
        canelButton = new Button();
        //setting the width and height of the window
        setMaxHeight(250);
        setMaxWidth(250);
        setMinHeight(250);
        setMinWidth(250);
        setPrefHeight(250);
        setPrefWidth(250);
        setSpacing(15);
        
        canelButton.setPrefHeight(25);
        canelButton.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        canelButton.setPrefWidth(70);
        canelButton.setText("Back");
        canelButton.setAlignment(javafx.geometry.Pos.CENTER);
        //margin for cancel button
        VBox.setMargin(canelButton, new Insets(5, 0, 0, 0));
        setPadding(new Insets(15));
        
        
        //setting the height and width of the return date field
        datePickerDateReturn.setPrefWidth(225);
        datePickerDateReturn.setPrefHeight(25);
        
        
        labelDatePickerDateReturn.setText("Return Date of vechicle");
        //setting margin for the screen 
        
        VBox.setMargin(labelDatePickerDateReturn, new Insets(15, 0, 0, 0));
        
        saveBtn.setPrefHeight(30);
        saveBtn.setPrefWidth(100);
        saveBtn.setAlignment(javafx.geometry.Pos.CENTER);
        saveBtn.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        saveBtn.setText("Click to Save");
        
     
        vBoxSaveBtn.setAlignment(javafx.geometry.Pos.CENTER);
        //setting margin for the button
        VBox.setMargin(vBoxSaveBtn, new Insets(15, 0, 0, 0));
        
       //Adding children to the screen window
        //label for the return date
        getChildren().add(labelDatePickerDateReturn);
        //label for return date
        getChildren().add(datePickerDateReturn);
        //buttons
        vBoxSaveBtn.getChildren().add(saveBtn);
        vBoxSaveBtn.getChildren().add(canelButton);
        getChildren().add(vBoxSaveBtn);

    }
}
