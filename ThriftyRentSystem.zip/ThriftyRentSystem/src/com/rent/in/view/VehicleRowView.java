package com.rent.in.view;

import javafx.scene.text.Font;
import javafx.scene.image.ImageView;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;

//border pane
public abstract class VehicleRowView extends BorderPane {
	
	protected final ImageView vechicleImage;
	protected final VBox fxImageView;
	protected final VBox fxRent;
	protected final VBox jfxDetails;
	protected final Button viewDetailsButton;
	protected final Label jfxType;
	protected final Label jfxVechicleSeats;
	protected final Label jfxVechicleStatus;
    protected final Label vechicleMake;
    protected final Label vechicleModel;
    protected final Label vechicleRate;
    protected final Label vechicleRentDays;
    
    

    public VehicleRowView() {
        fxImageView = new VBox();
        fxRent = new VBox();
        jfxDetails = new VBox();
        viewDetailsButton = new Button();
        jfxType = new Label();
        jfxVechicleSeats = new Label();
        jfxVechicleStatus = new Label();
        vechicleImage = new ImageView();
        vechicleMake = new Label();
        vechicleModel = new Label();
        vechicleRate = new Label();
        vechicleRentDays = new Label();
        
        //styling the container
        setMaxHeight(150);
        setPrefWidth(870);
        setMinHeight(150);
        setMinWidth(870);
        setMaxWidth(870);
        setPrefHeight(150);
        
        //setting the background and border color
        setStyle("-fx-background-color: fbeaeb; -fx-border-color: #2f3c7e; -fx-border-image-width: 1;");
        
       
        //image
        BorderPane.setAlignment(fxImageView, javafx.geometry.Pos.CENTER);
        fxImageView.setAlignment(javafx.geometry.Pos.CENTER);
        //fxImageView.setStyle("-fx-border-color: #2f3c7e; -fx-border-width: 2;");
        BorderPane.setMargin(fxImageView, new Insets(0));
        fxImageView.setPrefSize(180, 120);
        fxImageView.setMinSize(180, 120);
        fxImageView.setMaxSize(180, 120);
        
        //vechicle image
        vechicleImage.setFitWidth(160);
        vechicleImage.setFitHeight(100);
        vechicleImage.setPreserveRatio(true);
        vechicleImage.setPickOnBounds(true);
        setLeft(fxImageView);
        
        //setting details
        BorderPane.setAlignment(jfxDetails, javafx.geometry.Pos.CENTER);
        jfxDetails.setPrefWidth(112);
        jfxDetails.setPrefHeight(150);
        jfxDetails.setSpacing(5);
        jfxDetails.setPadding(new Insets(10, 5, 10, 5));
        jfxDetails.setStyle("-fx-border-color: #2f3c7e; -fx-border-width: 1;");
        setCenter(jfxDetails);
        vechicleMake.setText("Ford car");
        vechicleMake.setFont(new Font(15));
        jfxVechicleSeats.setText("5 Seater");
        vechicleModel.setText("Endevour model");
        jfxVechicleStatus.setText("Available");
        vechicleModel.setFont(new Font("System Bold", 20));
        VBox.setMargin(vechicleModel, new Insets(-9, 0, 0, 0));
        jfxType.setText("Car");
        VBox.setMargin(jfxType, new Insets(12, 0, 0, 0));
       
        //rent 
        BorderPane.setAlignment(fxRent, javafx.geometry.Pos.CENTER);
        fxRent.setAlignment(javafx.geometry.Pos.CENTER);
        fxRent.setPrefHeight(150);
        fxRent.setPrefWidth(114);
        fxRent.setStyle("-fx-border-color:#2f3c7e; -fx-border-width: 1;");   
        vechicleRate.setFont(new Font("System Bold", 20));
        vechicleRate.setText("$ 1300");
        vechicleRentDays.setText("Rent for 3 days");
        setRight(fxRent);
        
        //btn styling
        viewDetailsButton.setPrefWidth(75);
        viewDetailsButton.setPrefHeight(35);
        viewDetailsButton.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        viewDetailsButton.setText(" View");
        VBox.setMargin(viewDetailsButton, new Insets(20, 0, 0, 0));
        
        //adding items to window
        fxImageView.getChildren().add(vechicleImage);
        jfxDetails.getChildren().add(vechicleModel);
        jfxDetails.getChildren().add(vechicleMake);
        jfxDetails.getChildren().add(jfxVechicleSeats);
        jfxDetails.getChildren().add(jfxVechicleStatus);
        jfxDetails.getChildren().add(jfxType); 
        fxRent.getChildren().add(vechicleRate);
        fxRent.getChildren().add(vechicleRentDays);
        fxRent.getChildren().add(viewDetailsButton);

    }
}
