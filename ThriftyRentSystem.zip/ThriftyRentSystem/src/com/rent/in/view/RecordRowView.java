package com.rent.in.view;

import javafx.geometry.Insets;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;

public abstract class RecordRowView extends VBox {
    //declaration
	protected final GridPane gridPaneTop;
    protected final GridPane gridPaneCenter;
    protected final GridPane gridPaneBottom;
    protected final VBox vBoxLateFee;
    protected final Label labelForLateFee;
    protected final Label valueForLateFee;
    protected final VBox vboxRentalDate;
    protected final Label labelRentalDate;
    protected final Label valueRentalDate;
    protected final VBox vboxIdofRecord;
    protected final Label labelIdofRecord;
    protected final Label valueofIdRecord;
    protected final VBox vboxofActualReturnDate;
    protected final Label labelOfActualReturnDate;
    protected final Label valueOfActualReturnDate;
    protected final VBox vboxOfEstimatedReturnDate;
    protected final Label labelOfEstimatedReturnDate;
    protected final Label valueOfEstimatedReturnDate;
    protected final VBox vBoxofRentalFee;
    protected final Label labelofRentalFee;
    protected final Label valueOfRentalFee;
    protected final VBox vboxOfCustomerId;
    protected final Label labelofCustomerId;
    protected final Label valueofCustomerId;
    protected final ColumnConstraints constraintOfColumn;
    protected final ColumnConstraints constraintOfColumnZero;
    protected final ColumnConstraints constraintOfColumnOne;
    protected final ColumnConstraints constraintOfColumnTwo;
    protected final ColumnConstraints constraintOfColumnThree;
    protected final ColumnConstraints constraintOfColumnFour;
    protected final ColumnConstraints constraintOfColumnFive;
    protected final RowConstraints constraintOfRows;
    protected final RowConstraints constraintOfRowsZero;
    protected final RowConstraints constraintOfRowsOne;

    public RecordRowView() {
    	//initiazation
        gridPaneTop = new GridPane();
        gridPaneBottom = new GridPane();
        gridPaneCenter = new GridPane();
        constraintOfColumn = new ColumnConstraints();
        constraintOfColumnZero = new ColumnConstraints();
        constraintOfColumnOne = new ColumnConstraints();
        constraintOfColumnTwo = new ColumnConstraints();
        constraintOfColumnThree = new ColumnConstraints();
        constraintOfColumnFour = new ColumnConstraints();
        constraintOfColumnFive = new ColumnConstraints();
        constraintOfRows = new RowConstraints();
        constraintOfRowsZero = new RowConstraints();
        constraintOfRowsOne = new RowConstraints();
        vBoxLateFee = new VBox();
        labelForLateFee = new Label();
        valueForLateFee = new Label();
        vBoxofRentalFee = new VBox();
        labelofRentalFee = new Label();
        valueOfRentalFee = new Label();
        vboxRentalDate = new VBox();
        labelRentalDate = new Label();
        valueRentalDate = new Label();
        vboxOfEstimatedReturnDate = new VBox();
        labelOfEstimatedReturnDate = new Label();
        valueOfEstimatedReturnDate = new Label();
        vboxIdofRecord = new VBox();
        labelIdofRecord = new Label();
        valueofIdRecord = new Label();
        vboxofActualReturnDate = new VBox();
        labelOfActualReturnDate = new Label();
        valueOfActualReturnDate = new Label();
        vboxOfCustomerId = new VBox();
        labelofCustomerId = new Label();
        valueofCustomerId = new Label();
        
        //setting width and height
        setMaxWidth(500);
        setPrefWidth(500);
        setMinWidth(500);
        setMinHeight(200);
        setMaxHeight(200);
        setPrefHeight(200);
        setStyle("-fx-background-color: #fbeaeb; -fx-border-color: #eeeeee; -fx-border-width: 1 1 1 1;");
        
        //grid pane settings
        gridPaneTop.setPrefHeight(60);
        gridPaneTop.setPrefWidth(450);
        gridPaneCenter.setPrefHeight(60);
        gridPaneCenter.setPrefWidth(450);
        gridPaneBottom.setPrefHeight(60);
        gridPaneBottom.setPrefWidth(450);
        vboxOfCustomerId.setPadding(new Insets(0, 0, 0, 10));
        VBox.setMargin(gridPaneTop, new Insets(0));
        
        //setting row constraints
        constraintOfRowsZero.setMinHeight(10);
        constraintOfRowsZero.setPrefHeight(30);
        constraintOfRowsZero.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfRows.setMinHeight(10);
        constraintOfRows.setPrefHeight(30);
        constraintOfRows.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfRowsOne.setMinHeight(10);
        constraintOfRowsOne.setPrefHeight(30);
        constraintOfRowsOne.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

       //customer id
        vboxOfCustomerId.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);
        vboxOfCustomerId.setPrefHeight(60);
        vboxOfCustomerId.setPrefWidth(260);
        //vboxOfCustomerId.setStyle("-fx-border-color:  #2f3c7e; -fx-border-width: 2;");
        labelofCustomerId.setText("Customer ID");
        labelofCustomerId.setFont(new Font(12));
        valueofCustomerId.setText("CS_001");
        valueofCustomerId.setFont(new Font(12));
        valueOfRentalFee.setText("$1250");
        valueOfRentalFee.setFont(new Font(12));
        
       //grid pane
        GridPane.setColumnIndex(vboxOfCustomerId, 1);
        GridPane.setMargin(vboxOfCustomerId, new Insets(0));
        GridPane.setColumnIndex(vboxOfEstimatedReturnDate, 1);
        GridPane.setColumnIndex(vBoxLateFee, 1);
        GridPane.setMargin(vBoxLateFee, new Insets(0));
        GridPane.setColumnIndex(vboxofActualReturnDate, 2);
        

        //setting column constraints
        constraintOfColumn.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumn.setMinWidth(20);
        constraintOfColumn.setPrefWidth(110);
        constraintOfColumnZero.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumnZero.setMinWidth(20);
        constraintOfColumnZero.setPrefWidth(110);
        constraintOfColumnOne.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumnOne.setMinWidth(20);
        constraintOfColumnOne.setPrefWidth(110);
        constraintOfColumnTwo.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumnTwo.setMinWidth(20);
        constraintOfColumnTwo.setPrefWidth(110);
        constraintOfColumnThree.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumnThree.setMinWidth(20);
        constraintOfColumnThree.setPrefWidth(110);       
        constraintOfColumnFour.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumnFour.setMinWidth(10);
        constraintOfColumnFour.setPrefWidth(100);       
        constraintOfColumnFive.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        constraintOfColumnFive.setMinWidth(10);
        constraintOfColumnFive.setPrefWidth(100);
        
        //record id
        vboxIdofRecord.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        vboxIdofRecord.setPrefHeight(54);
        vboxIdofRecord.setPrefWidth(254);
        labelIdofRecord.setText("ID of record");
        labelIdofRecord.setFont(new Font(12));
        valueofIdRecord.setText("C_001 CS_001 02/05/2019");
        valueofIdRecord.setFont(new Font(12));
        
        //rent date
        vboxRentalDate.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        vboxRentalDate.setPrefHeight(60);
        vboxRentalDate.setPrefWidth(260);
        labelRentalDate.setText("Rent Date");
        labelRentalDate.setFont(new Font(12));
        valueRentalDate.setText("03/06/2012");
        valueRentalDate.setFont(new Font(12));

        //estimated return date
        vboxOfEstimatedReturnDate.setAlignment(javafx.geometry.Pos.CENTER);
        vboxOfEstimatedReturnDate.setPrefHeight(60);
        vboxOfEstimatedReturnDate.setPrefWidth(260);
        //vboxOfEstimatedReturnDate.setStyle("-fx-border-color:  #2f3c7e; -fx-border-width: 2;");
        labelOfEstimatedReturnDate.setText("Estimated Return Date");
        labelOfEstimatedReturnDate.setFont(new Font(12));
        valueOfEstimatedReturnDate.setText("02/06/2012");
        valueOfEstimatedReturnDate.setFont(new Font(12));
        
        //estimated return fee
        vBoxLateFee.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);
        vBoxLateFee.setPrefHeight(60);
        vBoxLateFee.setPrefWidth(260);
        //vBoxLateFee.setStyle("-fx-border-color:  #2f3c7e; -fx-border-width:2;");
        labelForLateFee.setText("Late Fee");
        labelForLateFee.setFont(new Font(12));
        valueForLateFee.setText("$1250");
        valueForLateFee.setFont(new Font(12));
        vBoxLateFee.setPadding(new Insets(0, 0, 0, 10));
        
        //estimated late fee
        labelofRentalFee.setText("Rent Fee");
        labelofRentalFee.setFont(new Font(12));
        vBoxofRentalFee.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        vBoxofRentalFee.setPrefHeight(60);
        vBoxofRentalFee.setPrefWidth(260);
        vBoxofRentalFee.setAlignment(javafx.geometry.Pos.CENTER_LEFT);
        vBoxofRentalFee.setPrefHeight(60);
        vBoxofRentalFee.setPrefWidth(260);

        
        //estimated return
        valueOfActualReturnDate.setText("02/05/2019");
        valueOfActualReturnDate.setFont(new Font(12));
        labelOfActualReturnDate.setText("Actual Return Date");
        labelOfActualReturnDate.setFont(new Font(12));
        vboxofActualReturnDate.setAlignment(javafx.geometry.Pos.CENTER_RIGHT);
        vboxofActualReturnDate.setPrefHeight(60);
        vboxofActualReturnDate.setPrefWidth(260);
        
        
        //adding elements to the window
        gridPaneTop.getColumnConstraints().add(constraintOfColumn);
        gridPaneTop.getColumnConstraints().add(constraintOfColumnZero);
        //inserting record id and customer id 
        gridPaneTop.getRowConstraints().add(constraintOfRows);
        vboxOfCustomerId.getChildren().add(labelofCustomerId);
        vboxOfCustomerId.getChildren().add(valueofCustomerId);
        gridPaneTop.getChildren().add(vboxOfCustomerId);
        vboxIdofRecord.getChildren().add(labelIdofRecord);
        vboxIdofRecord.getChildren().add(valueofIdRecord);
        gridPaneTop.getChildren().add(vboxIdofRecord);
        getChildren().add(gridPaneTop);
        gridPaneCenter.getColumnConstraints().add(constraintOfColumnOne);
        gridPaneCenter.getColumnConstraints().add(constraintOfColumnTwo);
        gridPaneCenter.getColumnConstraints().add(constraintOfColumnThree);
        gridPaneCenter.getRowConstraints().add(constraintOfRowsZero);
        //rental date
        vboxRentalDate.getChildren().add(labelRentalDate);
        vboxRentalDate.getChildren().add(valueRentalDate);
        gridPaneCenter.getChildren().add(vboxRentalDate);
        //estimated return datee
        vboxOfEstimatedReturnDate.getChildren().add(labelOfEstimatedReturnDate);
        vboxOfEstimatedReturnDate.getChildren().add(valueOfEstimatedReturnDate);
        gridPaneCenter.getChildren().add(vboxOfEstimatedReturnDate);
        //actual return date
        vboxofActualReturnDate.getChildren().add(labelOfActualReturnDate);
        vboxofActualReturnDate.getChildren().add(valueOfActualReturnDate);
        gridPaneCenter.getChildren().add(vboxofActualReturnDate);
        getChildren().add(gridPaneCenter);
        gridPaneBottom.getColumnConstraints().add(constraintOfColumnFour);
        gridPaneBottom.getColumnConstraints().add(constraintOfColumnFive);
        gridPaneBottom.getRowConstraints().add(constraintOfRowsOne);
        //late fee
        vBoxLateFee.getChildren().add(labelForLateFee);
        vBoxLateFee.getChildren().add(valueForLateFee);
        gridPaneBottom.getChildren().add(vBoxofRentalFee);
        //rental fee
        vBoxofRentalFee.getChildren().add(labelofRentalFee);
        vBoxofRentalFee.getChildren().add(valueOfRentalFee);
        gridPaneBottom.getChildren().add(vBoxLateFee);
        getChildren().add(gridPaneBottom);

    }
}
