package com.rent.in.view;

import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Insets;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;

public abstract class RentVehicleView extends VBox {
	protected final Label vechicleRentDays;
    protected final TextField txDays;
    protected final Label labelRentalDate;
    protected final DatePicker datepickerRentDate;
    protected final Label fxCustomerId;
    protected final TextField txCustomerId;
    protected final VBox vBoxSaveBtn;
    protected final Button canelButton;
    protected final Button saveBtn;
    

    public RentVehicleView() {
    	vechicleRentDays = new Label();
        txDays = new TextField();
        labelRentalDate = new Label();
        datepickerRentDate = new DatePicker();
    	fxCustomerId = new Label();
        txCustomerId = new TextField();
        vBoxSaveBtn = new VBox();
        canelButton = new Button();
        saveBtn = new Button();
        saveBtn.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        canelButton.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        //setting the styles for the rent vehicle window
        setSpacing(10);
        setMaxHeight(550);
        setMinHeight(550);
        setPrefHeight(550);
        setMaxWidth(450);
        setMinWidth(450);
        setPrefWidth(450);
        datepickerRentDate.setPrefHeight(27);
        datepickerRentDate.setPrefWidth(450);
        //label and input fields
        fxCustomerId.setText("Enter customer ID");
        VBox.setMargin(fxCustomerId, new Insets(20, 0, 0, 0));
        vechicleRentDays.setText("Expected no of rent days");
        VBox.setMargin(vechicleRentDays, new Insets(20, 0, 0, 0));
        labelRentalDate.setText("Select Rent Date");
        VBox.setMargin(labelRentalDate, new Insets(20, 0, 0, 0));
        vBoxSaveBtn.setAlignment(javafx.geometry.Pos.CENTER);
        VBox.setMargin(vBoxSaveBtn, new Insets(15, 0, 0, 0));
        
        //save button
        saveBtn.setAlignment(javafx.geometry.Pos.CENTER);
        saveBtn.setPrefHeight(30);
        saveBtn.setPrefWidth(110);
        saveBtn.setText("Save");
        
        //cancel button
        canelButton.setAlignment(javafx.geometry.Pos.CENTER);
        canelButton.setPrefHeight(30);
        canelButton.setPrefWidth(110);
        canelButton.setText("Cancel");
        VBox.setMargin(canelButton, new Insets(5, 0, 0, 0));
        setPadding(new Insets(15));
        
        //adding child elements to the window screen
        getChildren().add(fxCustomerId);
        getChildren().add(txCustomerId);      
        getChildren().add(vechicleRentDays);
        getChildren().add(txDays);
        getChildren().add(labelRentalDate);
        getChildren().add(datepickerRentDate);
        vBoxSaveBtn.getChildren().add(saveBtn);
        vBoxSaveBtn.getChildren().add(canelButton);
        getChildren().add(vBoxSaveBtn);

    }
}
