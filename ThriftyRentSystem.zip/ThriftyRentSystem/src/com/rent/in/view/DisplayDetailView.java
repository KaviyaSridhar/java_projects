package com.rent.in.view;

import javafx.geometry.Insets;
import com.rent.in.controller.Home;
import javafx.scene.text.Font;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;

public abstract class DisplayDetailView extends Home {
	//scrollpane for viewing the list of vechicles
    protected final ScrollPane jParentContainer;
    //all the nodes are set in a single vertical column which inlcudes content, titles,values, list of vechicles.
    protected final VBox contentVbox;
    protected final VBox titleVbox;
    protected final VBox valueVbox;
    protected final VBox topRecordVbox;
    protected final VBox recordsVbox;
    protected final VBox labelVbox;
    //The JavaFX ImageView control can display an image inside a JavaFX GUI.
    protected final ImageView vechicleImage;
    //all the nodes are set in a single horizontal row.
    protected final HBox deatilsHBbox;
    //buttons for maintenance and records label
    protected final Button maintenanceButton;
    protected final Button rentButon;
    //creating labels to display list of detailed view
    protected final Label vechicleModel;
    protected final Label vechicleId;
    protected final Label javaRecordLabel;
    protected final Label idValueLabel;
    protected final Label carMakeLabel;
    protected final Label yearLabel;
    protected final Label fxYearLabel;
    protected final Label fxMaintenanceLabel;
    protected final Label fxMaintenanceVal;
    protected final Label carSeatLabel;
    protected final Label fxSeatsVal;  
    protected final Label fxStatusLABEL;
    protected final Label fxStatusValue;
    protected final Label vechicleLabelType;
    protected final Label fxTypeValue;
  
   
    public DisplayDetailView() {
    	jParentContainer = new ScrollPane();
    	deatilsHBbox = new HBox(); 
        contentVbox = new VBox();
        titleVbox = new VBox();
        valueVbox = new VBox();
        topRecordVbox = new VBox();
        recordsVbox = new VBox();
        vechicleImage = new ImageView();
        maintenanceButton = new Button();
        rentButon = new Button();        
        javaRecordLabel = new Label();
        vechicleModel = new Label();
        labelVbox = new VBox();
        vechicleId = new Label();
        idValueLabel = new Label();      
        vechicleLabelType = new Label();
        fxTypeValue = new Label();
        yearLabel = new Label();
        fxYearLabel = new Label();
        carSeatLabel = new Label();
        fxSeatsVal = new Label();
        fxStatusLABEL = new Label();
        fxStatusValue = new Label();
        carMakeLabel = new Label();
        fxMaintenanceLabel = new Label();
        fxMaintenanceVal = new Label();
        
        jParentContainer.setHbarPolicy(javafx.scene.control.ScrollPane.ScrollBarPolicy.NEVER);

        contentVbox.setAlignment(javafx.geometry.Pos.TOP_LEFT);
        //contentVbox.setMargin(titleVbox, new Insets(20);

        double _w = 510;
        //content box width height and style
        contentVbox.setPrefHeight(700);
        contentVbox.setPrefWidth(900);
        contentVbox.setMinWidth(700);
        contentVbox.setMaxWidth(900);
        contentVbox.setSpacing(20);
        contentVbox.setStyle("-fx-background-color: WHITE;");
        //vechicle width height and style
        vechicleImage.setFitHeight(500);
        vechicleImage.setFitWidth(450);
        vechicleImage.setPreserveRatio(true);
        vechicleImage.setPickOnBounds(true);
        

        carMakeLabel.setText("Ford");
        carMakeLabel.setFont(new Font(28));
        carMakeLabel.setStyle("-fx-text-fill: #2f3c7e;;");
        //carMakeLabel.setStyle(
        	    //"-fx-text-fill: white;"+
        	    //"-fx-background-color: #2f3c7e;");
        
        VBox.setMargin(titleVbox, new Insets(0, 20, 0, 20));
        vechicleModel.setText("Endavour");
        vechicleModel.setFont(new Font(22));
        

        deatilsHBbox.setPrefHeight(145);
        deatilsHBbox.setPrefWidth(_w - 10);
        deatilsHBbox.setPadding(new Insets(0, 0, 0, 10));
        
        labelVbox.setPrefHeight(500);
        labelVbox.setPrefWidth(250);
        labelVbox.setSpacing(5);
        //labelVbox.setAlignment(javafx.geometry.Pos.);
        labelVbox.setStyle(
        	    "-fx-background-color: #FBEAEB;");
        
        valueVbox.setPrefHeight(155);
        valueVbox.setPrefWidth(400);
        valueVbox.setSpacing(5);
        valueVbox.setStyle("-fx-border-color: #2f3c7e;; -fx-border-width: 0 0 0 3;");
        valueVbox.setStyle(
        	    "-fx-background-color: #FBEAEB;");
        
        vechicleId.setText("ID");

        vechicleLabelType.setText("Type");

        carSeatLabel.setText("Seats");

        yearLabel.setText("Year");

        fxStatusLABEL.setText("Status");

        fxMaintenanceLabel.setText("Maintenance");
        labelVbox.setPadding(new Insets(10));

        
       //SETTING TEMP VALUES'
        fxTypeValue.setText("Car");
        idValueLabel.setText("C_001");
        fxStatusValue.setText("Available");
        fxSeatsVal.setText("7");
        fxYearLabel.setText("2019");
        fxMaintenanceVal.setText("05/05/2019");
        valueVbox.setPadding(new Insets(10));
        
        

        rentButon.setPrefHeight(35);
        rentButon.setPrefWidth(160);
        rentButon.setText("Car Rent");
        rentButon.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");
        maintenanceButton.setStyle(
        	    "-fx-text-fill: white;"+
        	    "-fx-background-color: #2f3c7e;");

        maintenanceButton.setPrefHeight(27);
        maintenanceButton.setPrefWidth(165);
        maintenanceButton.setText("Perform Maintenance");

        javaRecordLabel.setText("Records of Vehicle");
        javaRecordLabel.setFont(new Font(20));
        //styling records box
        recordsVbox.setPrefHeight(50);
        recordsVbox.setPrefWidth(890);
        VBox.setMargin(topRecordVbox, new Insets(20));
        contentVbox.setPadding(new Insets(15, 0, 0, 0));
        jParentContainer.setContent(contentVbox);
        
        titleVbox.getChildren().add(vechicleModel);
        titleVbox.getChildren().add(carMakeLabel);
        //IMAGE
        contentVbox.getChildren().add(vechicleImage);
        //table-headingd
        contentVbox.getChildren().add(titleVbox);
        labelVbox.getChildren().add(vechicleId);
        labelVbox.getChildren().add(yearLabel);
        labelVbox.getChildren().add(carSeatLabel);
        labelVbox.getChildren().add(vechicleLabelType); 
        labelVbox.getChildren().add(fxStatusLABEL);
        labelVbox.getChildren().add(fxMaintenanceLabel);
        //table-values
        deatilsHBbox.getChildren().add(labelVbox);
        valueVbox.getChildren().add(idValueLabel);
        valueVbox.getChildren().add(fxYearLabel);
        valueVbox.getChildren().add(fxSeatsVal);        
        valueVbox.getChildren().add(fxTypeValue);        
        valueVbox.getChildren().add(fxStatusValue);
        valueVbox.getChildren().add(fxMaintenanceVal);

        deatilsHBbox.getChildren().add(valueVbox);
        contentVbox.getChildren().add(deatilsHBbox);
        //buttons
        contentVbox.getChildren().add(rentButon);
        contentVbox.getChildren().add(maintenanceButton);
        //records
        topRecordVbox.getChildren().add(javaRecordLabel);
        topRecordVbox.getChildren().add(recordsVbox);
        contentVbox.getChildren().add(topRecordVbox);
        //container
        jContent.setCenter(jParentContainer);
    }
}
