package com.rent.in.view;

import javafx.geometry.Insets;
import com.rent.in.controller.Home;
import javafx.scene.control.ListView;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public abstract class DisplayVehiclesView extends Home {
	//vechicle make combobox
	protected final ComboBox vechicleMake;
	//ListView is used to allow a user to select one item or multiple items from a list of items
	protected final ListView jVehicles;
	//combobox for vechicle seats, type and status
	protected final ComboBox jfxVechicleSeats;
	protected final ComboBox jfxType;
	protected final ComboBox jfxVechicleStatus;
	//HBox lays out its children in a single horizontal row. 
	protected final HBox jFilter;
	//region for placing the nodes
	protected final BorderPane jParentContainer;
	
	//initialization
	public DisplayVehiclesView() {
        super();
        
        vechicleMake = new ComboBox();
        jVehicles = new ListView();
        jfxVechicleSeats = new ComboBox();        
        jfxType = new ComboBox();
        jFilter = new HBox();
        jfxVechicleStatus = new ComboBox();
        jParentContainer = new BorderPane();
        

        setStyle("-fx-background-color: black;");
        jParentContainer.setTop(jFilter);
        
        //setting width of the filter combobox
        jfxType.setPrefWidth(900);
        jfxVechicleSeats.setPrefWidth(900);
        jfxVechicleStatus.setPrefWidth(900);
        vechicleMake.setPrefWidth(900);
        
        //fx settings for the filter opitions
        BorderPane.setAlignment(jFilter, javafx.geometry.Pos.CENTER);
        jFilter.setPrefWidth(900);
        jFilter.setSpacing(5);
        jFilter.setPrefHeight(48);
        jFilter.setPadding(new Insets(20, 20, 20, 20));
        
        BorderPane.setAlignment(jVehicles, javafx.geometry.Pos.CENTER);
        jVehicles.setPrefHeight(200);
        jVehicles.setPrefWidth(900);
        jVehicles.setStyle("-fx-background-color:#fbeaeb;");
        jVehicles.setFocusTraversable( false );
        jParentContainer.setCenter(jVehicles);

        
        jContent.setStyle("-fx-background-color: #2f3c7e;");
        jFilter.getChildren().add(vechicleMake);
        jFilter.getChildren().add(jfxType);
        jFilter.getChildren().add(jfxVechicleStatus);
        jFilter.getChildren().add(jfxVechicleSeats);
        

        
        jBack.setDisable(true);
        jContent.setCenter(jParentContainer);
    }
}
