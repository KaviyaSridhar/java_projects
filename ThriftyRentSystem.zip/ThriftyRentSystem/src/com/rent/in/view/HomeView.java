package com.rent.in.view;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Alert;

// Home page view
public abstract class HomeView extends BorderPane {
    
	protected final BorderPane jContent;
	
	// creating menu bar for navigation, create car and van, files
	protected final Menu jWindow;
	protected final Menu jCreate;
	 protected final MenuBar jTop;
	protected final Menu jFile;
	
	//create menuitems under file
	 protected final MenuItem jImport;
	 protected final MenuItem jExport;
   
	 //create menu item car and van under create car or van
	protected final MenuItem jfVan;
    protected final MenuItem jCar;
   
    //create menu item for navigating back or quitting
    protected final MenuItem jBack;
    protected final MenuItem jQuit;
    
    
    //intializing 
    public HomeView() {
        
    	jfVan = new MenuItem();
        jWindow = new Menu();
        jBack = new MenuItem();
        jContent = new BorderPane();
        jQuit = new MenuItem();
        jCreate = new Menu();
        jCar = new MenuItem(); 
        jTop = new MenuBar();
        jFile = new Menu();
        jExport = new MenuItem();
        jImport = new MenuItem();
        
        //setting height and width for the home view
        setMaxHeight(700);
        setMaxWidth(900);
        setMinHeight(700);
        setMinWidth(900);
        setPrefHeight(700);
        setPrefWidth(900);
        
        //The alignment of the child within its area of the border pane.
        BorderPane.setAlignment(jTop, javafx.geometry.Pos.CENTER);
        
        //menu bar text
        jFile.setText("Files");
        //jExport.setText("Export");
        //jImport.setText("Import");
        jQuit.setText("Exit");
        jCreate.setText(" Create Car or Van");
        jCar.setText("Car");
        jfVan.setText("Van");
        jWindow.setText("Navigation");
        jBack.setText("Back to main");
        setTop(jTop);
        
      //The alignment of the child within its area of the border pane.
        BorderPane.setAlignment(jContent, javafx.geometry.Pos.CENTER);
        jContent.setPrefHeight(900);
        jContent.setPrefWidth(900);
        //jContent.setStyle("-fx-background-color: black;");
        setCenter(jContent);
        
        // add menu items to menu
        jFile.getItems().add(jQuit);
        //jFile.getItems().add(jExport);
        //jFile.getItems().add(jImport);
        
        jWindow.getItems().add(jBack);
        jCreate.getItems().add(jCar);
        jCreate.getItems().add(jfVan);
        
        //getting menu 
        jTop.getMenus().add(jCreate);
        jTop.getMenus().add(jWindow);
        jTop.getMenus().add(jFile);
    }
}
