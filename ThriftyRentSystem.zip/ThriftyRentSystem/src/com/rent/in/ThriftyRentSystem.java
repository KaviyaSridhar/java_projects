package com.rent.in;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.sql.SQLException;
import javafx.application.Application;
import com.rent.in.controller.DisplayVehicles;
import com.rent.in.model.Database;


public class ThriftyRentSystem extends Application {
    public static final String DB_ERROR = "Database access error";
    @Override
    public void start(Stage stage) throws Exception {
        try {
            Database.prepare();
            Parent root = new DisplayVehicles();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (ClassNotFoundException ex) {
            new Alert(Alert.AlertType.ERROR, "Database is not supported").showAndWait();
            System.exit(0);
        } catch (SQLException ex) {
            new Alert(Alert.AlertType.ERROR, DB_ERROR).showAndWait();
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
