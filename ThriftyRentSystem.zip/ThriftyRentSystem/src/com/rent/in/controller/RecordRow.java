package com.rent.in.controller;


import com.rent.in.view.RecordRowView;
import com.rent.in.model.RentalRecord;

public class RecordRow extends RecordRowView {

    public RecordRow(RentalRecord r) {
    	//set customer Id
    	valueofCustomerId.setText(r.getCId());
    	//set record id
        valueofIdRecord.setText(r.getRentalRecordId());
        //set rental date
        valueRentalDate.setText(r.getDateOfRent().getFormattedDate());
        //set estimated return date
        valueOfEstimatedReturnDate.setText(r.getEstimatedDateOfReturn().getFormattedDate());
        //set rental fee formatted to 2 decimal place
        valueOfRentalFee.setText(r.getFare() == null ? "" : String.format("$%.2f", r.getFare()));
        //set actual fee formatted to 2 decimal place
        valueOfActualReturnDate.setText(r.getRetunDate() == null ? "" : r.getRetunDate().getFormattedDate());
        //set late fee formatted to 2 decimal places
        valueForLateFee.setText(r.getLateFee() == null ? "" : String.format("$%.2f", r.getLateFee()));
    }
    
}
