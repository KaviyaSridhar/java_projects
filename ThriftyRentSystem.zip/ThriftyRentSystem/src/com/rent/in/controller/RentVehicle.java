package com.rent.in.controller;

import com.rent.in.ThriftyRentSystem;
import com.rent.in.model.DateTime;
import com.rent.in.model.Vehicle;
import com.rent.in.model.exception.InvalidIdException;
import com.rent.in.model.exception.NotAvailableException;
import com.rent.in.view.RentVehicleView;
import java.sql.SQLException;
import java.time.LocalDate;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

public class RentVehicle extends RentVehicleView {

    private Vehicle vehicle;
    
    
    private boolean checkValues() {
    	//if no rent date is chosen
    	if (datepickerRentDate.getValue() == null) {
            new Alert(Alert.AlertType.ERROR, "Please select a rent date").showAndWait();
            return false;
        }
    	//if the customer id field is left blank
    	else if (txCustomerId.getText().equals("")) {
            new Alert(Alert.AlertType.ERROR, "No customer id is entered").showAndWait();
            return false;
        } 
         else {
        	//if the number of days to rent is a invalid number 
            try {
                Integer.parseInt(txDays.getText());
            } catch (NumberFormatException e) {
                new Alert(Alert.AlertType.ERROR, "Please select valid no of days").showAndWait();
                return false;
            }
            return true;
        }
    }
    private void saveRecord() {
    	//checking all the fields before saving record
        if (checkValues()) {
        	//	getting day,month,year
        	LocalDate localDate = datepickerRentDate.getValue();
            DateTime dateTime = new DateTime(localDate.getDayOfMonth(), localDate.getMonthValue(), localDate.getYear());
            try {
                vehicle.rent(txCustomerId.getText(), dateTime, Integer.parseInt(txDays.getText()));
                new Alert(Alert.AlertType.INFORMATION, vehicle.getVehicleType() + " sucessfully rented").showAndWait();
                //close the window
                ((Stage)getScene().getWindow()).close();
            } catch (NotAvailableException | InvalidIdException e) {
            	//if invalid exception or not available exception
                new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
            } catch (ClassNotFoundException | SQLException e) {
            	//database error
                new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
            }
        }
    }
    
    
    public RentVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
        //cancel button
        canelButton.setOnAction((event) -> {
        	//cancel button window close
            ((Stage)getScene().getWindow()).close();
        });
        //save button
        saveBtn.setOnAction((event) -> {
        	//call save record function
            saveRecord();
        });
       
    }
}
