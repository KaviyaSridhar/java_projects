package com.rent.in.controller;

import java.util.ArrayList;
import java.sql.SQLException;
import com.rent.in.view.DisplayVehiclesView;
import com.rent.in.model.Vehicle;

//display vehicles 
public class DisplayVehicles extends DisplayVehiclesView {
	
    public DisplayVehicles() throws ClassNotFoundException, SQLException {
    	//setting the seats
    	jfxVechicleSeats.getItems().add("Seats");
        jfxVechicleSeats.getItems().add("4 Seats");
        jfxVechicleSeats.getItems().add("7 Seats");
        jfxVechicleSeats.getItems().add("15 Seats");
        jfxVechicleSeats.getSelectionModel().select(0);
        
        //setting the vechicle type
    	jfxType.getItems().add("Type");
    	jfxType.getItems().add("Car");
    	jfxType.getItems().add("Van");
        jfxType.getSelectionModel().select(0);
        
        //setting the vehicle status
        jfxVechicleStatus.getItems().add("Status");
        jfxVechicleStatus.getItems().add("Available");
        jfxVechicleStatus.getItems().add("Rented");
        jfxVechicleStatus.getItems().add("Maintenance");
        jfxVechicleStatus.getSelectionModel().select(0);
        
        //getting the model status,seats,make,type
        vechicleMake.getSelectionModel().selectedItemProperty().addListener((observable) -> {
        	try {
                loadVehicles();
            } catch (Exception ex) { }
        });
        
        jfxType.getSelectionModel().selectedItemProperty().addListener((observable) -> {
        	try {
                loadVehicles();
            } catch (Exception ex) { }
        });
        
        jfxVechicleStatus.getSelectionModel().selectedItemProperty().addListener((observable) -> {
        	try {
                loadVehicles();
            } catch (Exception ex) { }
        });
        
        jfxVechicleSeats.getSelectionModel().selectedItemProperty().addListener((observable) -> {
        	try {
                loadVehicles();
            } catch (Exception ex) { }
        });
        
        loadMakes();
        loadVehicles();
    }
    public void refresh() {
        try {
            loadVehicles();
        } catch (Exception ex) { }
    }
    private void loadVehicles() throws ClassNotFoundException, SQLException {
    	//loading all the vehicles from the database
        Vehicle.ImportFromDatabase();
        //clear the items
        jVehicles.getItems().clear();
        //looping through the vechicles list
        for (Vehicle v : Vehicle.vechicleList) {
            int seatFilter = 0;
            try {
            	//number format exception
                seatFilter = Integer.parseInt(jfxVechicleSeats.getSelectionModel().getSelectedItem().toString().split(" ")[0]);
            } catch (NumberFormatException ex) { }
            
            boolean validMake =(vechicleMake.getSelectionModel().getSelectedItem().toString().toLowerCase().equals(v.getMake().toLowerCase()) || (vechicleMake.getSelectionModel().getSelectedIndex() == 0) );
           
            boolean validType = (jfxType.getSelectionModel().getSelectedItem().toString().equals(v.getVehicleType()) || (jfxType.getSelectionModel().getSelectedIndex() == 0));
            
            boolean validSeat =(v.getSeatNumber() == seatFilter || (jfxVechicleSeats.getSelectionModel().getSelectedIndex() == 0)) ;
            
            boolean validStatus = (jfxVechicleStatus.getSelectionModel().getSelectedItem().toString().equals(v.getStatusOfVehicle()) || (jfxVechicleStatus.getSelectionModel().getSelectedIndex() == 0 ));
            
            //checking the status before adding 
            if (validSeat && validType && validStatus && validMake)
            	//getting items
            	jVehicles.getItems().add(new VehicleRow(v));
        }
    }
    
    private void loadMakes() throws ClassNotFoundException, SQLException {
    	//
        vechicleMake.getItems().clear();
        vechicleMake.getItems().add("Make");
        vechicleMake.getSelectionModel().select(0);
        
        ArrayList<String> vehicleMakes = Vehicle.GetAllMakes();
        for (String sVechicle : vehicleMakes)
            vechicleMake.getItems().add(sVechicle);
    }
    
   
    
    
}
