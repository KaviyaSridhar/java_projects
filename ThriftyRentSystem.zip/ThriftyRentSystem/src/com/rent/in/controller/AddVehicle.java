package com.rent.in.controller;

import com.rent.in.model.exception.IdExistsException;
import com.rent.in.view.AddVehicleView;
import com.rent.in.model.exception.InvalidIdException;
import com.rent.in.ThriftyRentSystem;
import com.rent.in.model.Vehicle;
import javafx.scene.control.Alert;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;

public class AddVehicle extends AddVehicleView {
    File savedImageFile;
    
    public AddVehicle(boolean isCar) {
    	//cancel button to quit the current window
        canelButton.setOnAction((event) -> {
        	//window close
            ((Stage)getScene().getWindow()).close();
        });
        
        //we add items car and van
        jfxType.getItems().add("Van");
        jfxType.getItems().add("Car");
        
        
        
        jfxType.getSelectionModel().selectedItemProperty().addListener((observable) -> {
        	//if the type is of car or van
            if (jfxType.getSelectionModel().getSelectedItem().equals("Car")) {
            	//adding the seats number 4 and 7 when its car
                jfxVechicleSeats.getItems().clear();
                jfxVechicleSeats.getItems().add(4);
                jfxVechicleSeats.getItems().add(7);
                jfxVechicleSeats.getSelectionModel().selectFirst();
                //setting the text field with C_ if it is blank 
                if (jtxId.getText().equals("")) jtxId.setText("C_");
                else if (jtxId.getText().startsWith("V_"))
                	//else replacing the V_ with C_
                    jtxId.setText(jtxId.getText().replace("V_", "C_"));
            } else {
            	//adding seat number 15 if the type is van
                jfxVechicleSeats.getItems().clear();
                jfxVechicleSeats.getItems().add(15);
                jfxVechicleSeats.getSelectionModel().selectFirst();
                //setting the text field with C_ if it is blank 
                if (jtxId.getText().equals("")) jtxId.setText("V_");
                else if (jtxId.getText().startsWith("C_"))
                	//else replacing the C_ with V_
                    jtxId.setText(jtxId.getText().replace("C_", "V_"));
            }
        });
        //if the type is car
        if (isCar) jfxType.getSelectionModel().select("Car");
        //else if the type is van
        else jfxType.getSelectionModel().select("Van");
        
        //adding image button opens the dialog box
        addImageBtn.setOnAction((event) -> {
            FileChooser fileChooser = new FileChooser();
            savedImageFile = fileChooser.showOpenDialog(getScene().getWindow());
        });
        
        // validating the year 
        yearText.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.equals("")) {
                try {
                    Integer.parseInt(newValue);
                    //if the length of the year is greater than 4 error
                    if (newValue.length() > 4) throw new Exception();
                } catch (Exception exp) {
                	// if exception occurs old year is set
                    yearText.setText(oldValue);
                }
            }
        });
        
       //save button calls the save vehicle method
        saveBtn.setOnAction((event) -> {
            saveVehicle();
        });
    }
    private void saveVehicle() {
    	
        String vechicleType = jfxType.getSelectionModel().getSelectedItem().toString();
        try {
        	//if the values are validated
            if (checkValues()) {
            	//adding the vehicle to the system
                Vehicle.addingVehicleToApplication(
                    jtxId.getText(), yearText.getText(), textCarMake.getText(), modelText.getText(),
                    Integer.parseInt(jfxVechicleSeats.getSelectionModel().getSelectedItem().toString()),
                    jfxType.getSelectionModel().getSelectedItem().toString(), Vehicle.vehicleAvailable
                );
                try {
                	//calling save image function
                    saveImage();
                    //successfully added the vehicle
                    new Alert(Alert.AlertType.INFORMATION, "A new " + vechicleType + "  successfully added").showAndWait();
                } catch (IOException e) {
                	//input exception
                    new Alert(Alert.AlertType.ERROR, "Saved the " + vechicleType + " image saving failed " + vechicleType).showAndWait();
                } finally {
                    ((Stage)getScene().getWindow()).close();
                }
            }
        } catch (IdExistsException e) {
        	//id already exixts exception
            new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        } catch (InvalidIdException e) {
        	//invalid car id exception
            if (vechicleType.equals("Car")) {
            	//if the car id does not start with c_
                if (!jtxId.getText().toLowerCase().startsWith("c_")) 
                    new Alert(Alert.AlertType.ERROR, "Car must start with C_ ").showAndWait();
            } else {
            	//if the van does not start with v_
                if (!jtxId.getText().toLowerCase().startsWith("v_")) 
                    new Alert(Alert.AlertType.ERROR, "Van must start with V_").showAndWait();
            }
        } catch (ClassNotFoundException | SQLException ex) {
        	//data base error
            new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
        }
    }
    
    private void saveImage() throws IOException {
        // if the image file is not null
    	if (savedImageFile != null) {
            Files.copy(savedImageFile.toPath(), Vehicle.pathTwoForImageVehile(textCarMake.getText(), modelText.getText()), StandardCopyOption.REPLACE_EXISTING);
        }
    }
    
    //checking the values before saving the vehicle
    private boolean checkValues() {
    	//if the year feild is empty 
    	if (yearText.getText().length() != 4) {
            new Alert(Alert.AlertType.ERROR, "Please Enter valid manufacture year").showAndWait();
            return false;
        } // if the car make is empty
    	else if (textCarMake.getText().equals("")) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Make of vehicle").showAndWait();
            return false;
        }//if the model is empty
        else if (modelText.getText().equals("")) {
            new Alert(Alert.AlertType.ERROR, "Please Enter Model of vehicle").showAndWait();
            return false;
        }
         
        else 
        	return true;
    }
}
