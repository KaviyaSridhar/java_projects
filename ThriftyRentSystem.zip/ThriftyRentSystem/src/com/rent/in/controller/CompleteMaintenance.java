package com.rent.in.controller;


import javafx.stage.Stage;
import javafx.scene.control.Alert;
import com.rent.in.view.DateSelectionView;
import java.time.LocalDate;
import com.rent.in.model.DateTime;
import com.rent.in.ThriftyRentSystem;
import com.rent.in.model.Vehicle;
import com.rent.in.model.Van;
import com.rent.in.model.exception.NotAvailableForMaintenanceCompletionException;
import java.sql.SQLException;

//method for completing maintenance of an vehicle
public class CompleteMaintenance extends DateSelectionView {
    
    private Vehicle vehicle;
    
    public CompleteMaintenance(Vehicle vehicle) {
        this.vehicle = vehicle;
        //displaying save and cancel  button to the user
        //if the cancel button is clicked the window is closed
        canelButton.setOnAction((event) -> {
            ((Stage)getScene().getWindow()).close();
        });
      //if the user clicks the sace button complete maintenance is called
        saveBtn.setOnAction((event) -> {
            completeMaintenance();
        });
        //datepicker for vechicle maintenance completion date
        labelDatePickerDateReturn.setText("Date of completion for maintenance");
    }
    
    private void completeMaintenance() {
    	//if date is selected 
        if (datePickerDateReturn.getValue() != null)
        {LocalDate dateMaintenance = datePickerDateReturn.getValue();
        DateTime dateTime = new DateTime(dateMaintenance.getDayOfMonth(), dateMaintenance.getMonthValue(), dateMaintenance.getYear());
        try {
            ((Van)vehicle).completeMaintenance(dateTime);
            new Alert(Alert.AlertType.INFORMATION, vehicle.getVehicleType() + 
            		" Maintenance completed successfully").showAndWait();
            //close window
            ((Stage)getScene().getWindow()).close();
        } catch (ClassNotFoundException | SQLException e) {
        	//invalid id exception
            new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
        } catch (NotAvailableForMaintenanceCompletionException e) {
        	//sql and class not found exception
            new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
        }
        }
        else {
        	//null value for the date
            new Alert(Alert.AlertType.ERROR, "Please select date of completion").showAndWait();
 
        }
    }
}
