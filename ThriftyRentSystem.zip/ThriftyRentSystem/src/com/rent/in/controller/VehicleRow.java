package com.rent.in.controller;

import javafx.stage.Stage;
import com.rent.in.view.VehicleRowView;
import javafx.scene.Scene;
//import com.rent.in.view.VehicleRowView;
import javafx.scene.image.Image;
import com.rent.in.model.Vehicle;

public class VehicleRow extends VehicleRowView {

    public VehicleRow(Vehicle v) {
    	 //setting vechicle seats
        jfxVechicleSeats.setText("Seats : " + String.valueOf(v.getSeatNumber()));
    	//setting vechicle rate
        vechicleRate.setText(String.format("$%.0f", v.threeDayRent()));
    	//setting vechicle model
    	vechicleModel.setText(v.getModel());
    	//getting the vechicle type
    	jfxType.setText(String.format("Type : %s", v.getVehicleType()));
    	//setting vechicle make
        vechicleMake.setText(v.getMake());
        //setting vechicle status
        jfxVechicleStatus.setText(v.getStatusOfVehicle());
        //getting img
        Image image = new Image(v.getPathOfVehicleImage());
        if (image.isError())
        	//if there is error we display a default image to the user
        	vechicleImage.setImage(new Image(getClass().getResourceAsStream("/com/rent/in/view/default_img.png")));
        else
        	//the image is set if there is no error
        	vechicleImage.setImage(image);
        //when the view detail button is clicked displaydetail.java is called
        viewDetailsButton.setOnAction((event) -> {
            Stage s = new Stage();
            DisplayDetail vehicleDetail = new DisplayDetail(v);
            s.setScene(new Scene(vehicleDetail));
            s.show();
            ((Stage)getScene().getWindow()).close();
        });
    }
}
