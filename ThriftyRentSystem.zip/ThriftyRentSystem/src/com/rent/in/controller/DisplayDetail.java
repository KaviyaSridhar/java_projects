package com.rent.in.controller;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import com.rent.in.ThriftyRentSystem;
import com.rent.in.model.Car;
import com.rent.in.view.DisplayDetailView;
import com.rent.in.model.RentalRecord;
import com.rent.in.model.Vehicle;
import com.rent.in.model.Van;
import com.rent.in.model.exception.InvalidIdException;
import java.sql.SQLException;
import com.rent.in.model.exception.NotAvailableForMaintenanceException;


public class DisplayDetail extends DisplayDetailView {
    private final Vehicle v;
   // initializing the v status 
    private final static String vehicleUnderMaintenance = "Perform Maintenance";
    private final static String RETURN = "Return";
    private final static String COMPLETE_MAINTENANCE = "Complete Maintenance";
    private final static String RENT = "Rent";
    
    //displaying the detailed v view
    public DisplayDetail(Vehicle v) {
        this.v = v;
        fxYearLabel.setText(v.getYear());
        fxSeatsVal.setText(String.valueOf(v.getSeatNumber()));
        fxTypeValue.setText(v.getVehicleType());
        vechicleImage.setImage(v.getVehicleImage());
        idValueLabel.setText(v.getIdOfVehicle());
        carMakeLabel.setText(v.getMake());
        vechicleModel.setText(v.getModel());
        
        //if the vehicle is of instance car
        if (v instanceof Car) {
        	//maintenance label, value and button is set to false
        	fxMaintenanceVal.setVisible(false);
            fxMaintenanceVal.setManaged(false);
            maintenanceButton.setVisible(false);
            maintenanceButton.setManaged(false);
            fxMaintenanceLabel.setVisible(false);
            fxMaintenanceLabel.setManaged(false);
         
        }
        
        //if the maintenance button is called 
        maintenanceButton.setOnAction((event) -> {
        	//if the vehicle is under maintenance
        	if (v.getStatusOfVehicle().equals(Vehicle.vehicleUnderMaintenance)) {
        		Parent p = new CompleteMaintenance(v);
                Stage s = new Stage();
                s.setScene(new Scene(p));
                s.showAndWait();
                refresh();
            }
        	// if the vehicle status is available
        	else if (v.getStatusOfVehicle().equals(Vehicle.vehicleAvailable)) {
                try {
                	//calling performance maintenance function
                    ((Van)v).performMaintenance();
                    refresh();
                } //if the vehicle is not available for maintenace
                catch (NotAvailableForMaintenanceException | InvalidIdException e) {
                    new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
                } catch (ClassNotFoundException | SQLException ex) {
                    new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
                }
            }  
        });
        
 
        //onlcick rent button
        rentButon.setOnAction((event) -> {
            Stage s = new Stage();
            Parent p = null; 
            if (v.getStatusOfVehicle().equals(Vehicle.vehicleRented)) 
                p = new ReturnVehicle(v);
            else if (v.getStatusOfVehicle().equals(Vehicle.vehicleAvailable)) 
            	p = new RentVehicle(v);
            s.setScene(new Scene(p));
            s.showAndWait();
            refresh();
        });
        refresh();
    }
    //loading all the child records from the rental record 
    private void loadRecords() {
        recordsVbox.getChildren().clear();
        for (RentalRecord record : v.getRecords())
            recordsVbox.getChildren().add(new RecordRow(record));
    }
    
    private void refresh() {
    	//setting the rent and maintenance button to false
    	maintenanceButton.setDisable(false);
        rentButon.setDisable(false);
        //setting the text of the rent and the maintenance button
        rentButon.setText(RENT);
        maintenanceButton.setText(vehicleUnderMaintenance);
        if(v.getStatusOfVehicle().equals(Vehicle.vehicleUnderMaintenance)) {
        	//disabling the rent button
            rentButon.setDisable(true);
            //setting the maintenance button to complete maintenance
            maintenanceButton.setText(COMPLETE_MAINTENANCE);
        }
        
        else if (v.getStatusOfVehicle().equals(Vehicle.vehicleRented)) {
        	//setting the rent button to return
            rentButon.setText(RETURN);
            //setting the maintenance button to true
            maintenanceButton.setDisable(true);
        } 
        //setting the status of the vechicle
        fxStatusValue.setText(v.getStatusOfVehicle());
        
        //if vehicle instance is van
        if (v instanceof Van)
        	//gettig the maintenance date value
            fxMaintenanceVal.setText(((Van)v).getMaintanenceDate().getFormattedDate());
        loadRecords();
    }
    
   
}
