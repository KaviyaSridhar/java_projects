package com.rent.in.controller;

import java.io.*;
import java.nio.file.Files;
import java.sql.SQLException;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert;
import javafx.stage.DirectoryChooser;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.rent.in.view.HomeView;
import com.rent.in.model.Vehicle;
import com.rent.in.ThriftyRentSystem;
import com.rent.in.model.Database;

public class Home extends HomeView {

    public Home() {
    	//event for adding car 
    	jCar.setOnAction((event)       ->      {   addVehicle(true);   });
    	//event for adding van
    	jfVan.setOnAction((event)       ->      {   addVehicle(false);  });
    	//event for displaying all the vechicles
        jBack.setOnAction((event)      ->      {   displayVehicles();  });
        //event for exiting 
        jQuit.setOnAction((event)      ->      {   exitApp();          });
        //event for importing 
        jImport.setOnAction((event)    ->      {   importData();       });
        // event for exporting
        jExport.setOnAction((event)    ->      {   exportData();       });
    }
    
    //method for getting the export file
    private File getFileForExporting() {
        DirectoryChooser directory = new DirectoryChooser();
        //getting the list of vehicles from the scene
        File f = directory.showDialog(getScene().getWindow());
        //if the file is not equal to Null we return the file to absolute path
        if (f != null) 
            return new File(f.getAbsolutePath() + "/export_data.txt");
        //else we return null
        else return null;
    }
    
    //method to add vehicle car and van
    private void addVehicle(boolean checkVehicleType) {
    	//stage class
        Stage s = new Stage();
        //displaying vehicle
        AddVehicle displayListOfVehicles = new AddVehicle(checkVehicleType);
        s.setScene(new Scene(displayListOfVehicles));
        //show stage
        s.show();
    }
    
    //method to display all the vechicles list
    private void displayVehicles() {
    	//try displaying all the vehicles
        try {
            Stage s = new Stage();
            DisplayVehicles displayListOfVehicles = new DisplayVehicles();
            s.setScene(new Scene(displayListOfVehicles));
            s.show();
            //getting scene window and close
            ((Stage)getScene().getWindow()).close();
        } //else catch exception
        catch (ClassNotFoundException | SQLException e) {
        	//alert box to display error message
            new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
        }
    }
    
    //method for importing the data
    private void importData() {
    	//calling the getFileForExporting method for getting the file
        File f = getFileForExporting();
        //if the file is not equal to null
        if (f != null) {
        	//
            try {
            	//calling the clearrecord method in the databse 
                Database.clearRecords();
                //reading all bytes
                String getdata = new String(Files.readAllBytes(f.toPath()));
                //storing in a vechicle array
                String[] v = getdata.split("\n\n");
                for (String vehicleList : v) Vehicle.ImportVehicle(vehicleList);
                new Alert(Alert.AlertType.INFORMATION, "file is imported successfully " + 
                f.getAbsolutePath()).showAndWait();
                //if found to be a instance calling the refresh
                if (this instanceof DisplayVehicles) 
                	((DisplayVehicles)this).refresh();
            } catch (IOException e) {
            	//input output exception
                new Alert(Alert.AlertType.ERROR, "Error reading file, file (export_data.txt) should exist in the path").showAndWait();
            } catch (ClassNotFoundException | SQLException e) {
            	//sql and class not found exception
                new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
            }
        }
    }
    
    private void exportData() {
    	
        File f = getFileForExporting();
        if (f != null) {
            String exportData = "";
            for (Vehicle vechicle : Vehicle.vechicleList) 
            	exportData = exportData.concat(vechicle.toString());
            try {
            	//writing the file
                FileWriter fileWriter = new FileWriter(f);
                fileWriter.write(exportData);
                fileWriter.flush();
                fileWriter.close();
                //sucessful message
                new Alert(Alert.AlertType.INFORMATION, "Successfully exported to file " + f.getAbsolutePath()).showAndWait();
            } catch (IOException e) {
                new Alert(Alert.AlertType.ERROR, "An error occured while trying to write file").showAndWait();
            }
        }
    }
    
    private void exitApp() {
    	//alert box for exiting the window
        new Alert(Alert.AlertType.CONFIRMATION, "Do you want to quit ?",
        		// alerting the user to select yes or no
        		new ButtonType[] {ButtonType.YES, ButtonType.NO }).showAndWait().ifPresent(type -> {
        //if the input from the user is yes system.exit(0)
        	if (type == ButtonType.YES) System.exit(0);
        });
    }
    
    
    
    
   
    
    
    
}
