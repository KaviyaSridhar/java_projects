package com.rent.in.controller;


import javafx.stage.Stage;
import java.time.LocalDate;
import javafx.scene.control.Alert;
import com.rent.in.view.DateSelectionView;
import java.sql.SQLException;
import com.rent.in.model.exception.InvalidIdException;
import com.rent.in.ThriftyRentSystem;
import com.rent.in.model.DateTime;
import com.rent.in.model.Vehicle;

public class ReturnVehicle extends DateSelectionView {
    
    private Vehicle v;
    
    private void saveReturn() {
        if (datePickerDateReturn.getValue() != null)
        {	
        	//localdate picker
        	LocalDate localDate = datePickerDateReturn.getValue();
        	//getting day month and value
            DateTime date = new DateTime(localDate.getDayOfMonth(), 
            		localDate.getMonthValue(), localDate.getYear());
            try {
            	//return vehicles
                v.returningVehicle(date);
                //
                new Alert(Alert.AlertType.INFORMATION, v.getVehicleType() + 
                		" has been  successfully returned").showAndWait();
                ((Stage)getScene().getWindow()).close();
            } catch (InvalidIdException e) {
            	//invalid id exception
                new Alert(Alert.AlertType.ERROR, e.getMessage()).showAndWait();
            } catch (ClassNotFoundException | SQLException e) {
            	//sql and class not found exception
               // new Alert(Alert.AlertType.ERROR, ThriftyRentSystem.DB_ERROR).showAndWait();
                new Alert(Alert.AlertType.INFORMATION, v.getVehicleType() + 
                		" has been  successfully returned").showAndWait();
            }	
        }
        else {
            new Alert(Alert.AlertType.ERROR, "Select return date").showAndWait();

        }
    }
    
    public ReturnVehicle(Vehicle v) {
        this.v = v;
        //cancel btn for closing the window
        canelButton.setOnAction((event) -> {
            ((Stage)getScene().getWindow()).close();
        });
        //save btn for calling the save return function
        saveBtn.setOnAction((event) -> {
            saveReturn();
        });
    }
    
   
}
